/**
 * AT89S52 LED & Buzzer Controller with Frequency Sweep
 * Hardware:
 * - 12MHz crystal
 * - LED on P2.0
 * - Passive buzzer on P2.1
 * - Button on P3.2 (INT0)
 * Features:
 * - Toggles LED every 50ms when active
 * - Generates zig-zag frequency sweep (1kHz-3kHz) while active
 * - Button controls on/off state
 */

#include <reg52.h>    // Standard 8051 registers
#include <intrins.h>  // Required for _nop_()

/* Hardware Connections */
sbit LED = P2^0;     // LED connected to P2.0
sbit BUZZER = P2^1;  // Passive buzzer on P2.1
sbit BUTTON = P3^2;  // Pushbutton on P3.2 (INT0)

/* Global Variables */
bit isActive = 0;    // System state flag
bit sweepDirection = 0; // 0=rising, 1=falling frequency
unsigned int currentFreqDelay = 250; // Start at 2kHz (250us half-period)

/**
 * Timer 0 Interrupt Service Routine
 * - Called every 1ms (with 12MHz crystal)
 * - Manages LED timing
 */
void Timer0_ISR(void) interrupt 1
{
    static unsigned int msCount = 0;
    
    TH0 = 0xFC;  // Reload for 1ms @ 12MHz
    TL0 = 0x66;
    
    if(isActive) {
        if(++msCount >= 50) {  // 50ms period
            LED = !LED;        // Toggle LED
            msCount = 0;
        }
    }
}

/**
 * External Interrupt 0 Service Routine
 * - Triggered by button press
 * - Toggles system state
 */
void INT0_ISR(void) interrupt 0
{
    isActive = !isActive;  // Toggle state
    
    // Turn off outputs when deactivated
    if(!isActive) {
        LED = 0;
        BUZZER = 0;
    }
    
    // Simple debounce delay
    _nop_(); _nop_(); _nop_(); _nop_(); _nop_();
    _nop_(); _nop_(); _nop_(); _nop_(); _nop_();
    while(!BUTTON);  // Wait for button release
}

/**
 * Generate tone with variable frequency
 * @param duration_ms - how long to beep (in ms)
 * @param freq_delay - half-period delay in NOP cycles
 */
void beep_variable(unsigned int duration_ms, unsigned int freq_delay)
{
    unsigned int i, d;
    for(i = 0; i < duration_ms; i++) {
        BUZZER = !BUZZER;  // Toggle buzzer pin
        for(d = 0; d < freq_delay; d++){_nop_();} // Variable delay                
    }
    BUZZER = 0;
}

/**
 * Update frequency for sweep effect
 * - Sweeps between 1kHz (500us) and 3kHz (166us)
 * - Changes direction at limits
 */
void updateSweepFrequency(void)
{
    if(!sweepDirection) {
        // Rising frequency (lower delay)
        if(currentFreqDelay > 166) currentFreqDelay -= 2;
        else sweepDirection = 1;
    }
    else {
        // Falling frequency (higher delay)
        if(currentFreqDelay < 500) currentFreqDelay += 2;
        else sweepDirection = 0;
    }
}

/**
 * Main Program
 */
void main(void)
{
    /* Initialize Hardware */
    LED = 0;      // Start with LED off
    BUZZER = 0;   // Start with buzzer off
    BUTTON = 1;   // Enable pull-up
    
    /* Timer 0 Setup (1ms interrupts) */
    TMOD = 0x01;  // Timer 0, Mode 1 (16-bit)
    TH0 = 0xFC;   // Initial values for 1ms
    TL0 = 0x66;   // @12MHz
    ET0 = 1;      // Enable Timer 0 interrupt
    TR0 = 1;      // Start Timer 0
    
    /* Interrupt Configuration */
    IT0 = 1;      // INT0 edge-triggered
    EX0 = 1;      // Enable INT0 interrupt
    EA = 1;       // Global interrupt enable
    
    /* Main Super Loop */
    while(1) {
        if(isActive) {
            beep_variable(10, currentFreqDelay); // Short beep with current frequency
            updateSweepFrequency();             // Update frequency for sweep effect
        }
    }
}