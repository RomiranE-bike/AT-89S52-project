#include <reg52.h>

/*----- Hardware Connections -----*/
// Status LEDs (P2)
sbit POWER_LED = P2^0;
sbit SPEED_LED = P2^1;
sbit RANGE_LED = P2^2;

// Pattern LEDs (P2)
sbit UP_LED     = P2^3;
sbit DOWN_LED   = P2^4;
sbit ZIGZAG_LED = P2^5;

// Audio outputs (P3)
sbit BUZZER = P3^0;
sbit BUZZER_INV = P3^1;

// Buttons (P3)
sbit BTN_POWER   = P3^2;
sbit BTN_PATTERN = P3^3;
sbit BTN_SPEED   = P3^4;
sbit BTN_RANGE   = P3^5;

/*----- System State -----*/
bit isActive = 0;
bit currentRange = 0;
unsigned char currentPattern = 0;
unsigned char currentSpeed = 1;  // Default medium speed

/*----- Sound Parameters -----*/
unsigned int currentFreqDelay;
const unsigned int rangeParams[2][3] = {
    {25, 50, 37},  // 5-10kHz range
    {9, 18, 13}    // 18-27kHz range
};

/*----- Optimized Functions -----*/
void delay_ms(unsigned int ms) {
    while(ms--) {
        unsigned char x = 120;
        while(x--);
    }
}

void updateLEDs() {
    P2 = 0xFF;  // All LEDs off
    
    // Power and range indicators
    POWER_LED = !isActive;
    RANGE_LED = !currentRange;
    
    // Pattern indicator (only one active)
    switch(currentPattern % 6) {  // Reduced to core patterns
        case 0: UP_LED = 0; break;
        case 1: DOWN_LED = 0; break;
        case 2: ZIGZAG_LED = 0; break;
    }
}

bit checkButton(sbit pin) {
    static bit lastState[4] = {1,1,1,1};
    bit current = pin;
    unsigned char idx = (pin == BTN_POWER) ? 0 : 
                       (pin == BTN_PATTERN) ? 1 :
                       (pin == BTN_SPEED) ? 2 : 3;
    
    if(current != lastState[idx]) {
        delay_ms(20);
        if(pin == current) {
            lastState[idx] = current;
            return !current;
        }
    }
    return 0;
}

void generate_tone() {
    static unsigned int counter = 0;
    if(++counter >= currentFreqDelay) {
        counter = 0;
        BUZZER = !BUZZER;
        BUZZER_INV = ~BUZZER;
    }
}

void update_sweep() {
    unsigned int min = rangeParams[currentRange][0];
    unsigned int max = rangeParams[currentRange][1];
    static bit dir = 0;
    static unsigned int pulseCount = 0;

    switch(currentPattern % 6) {  // Core patterns only
        case 0: // Up
            if(currentFreqDelay > min) currentFreqDelay--;
            else currentFreqDelay = max;
            break;
            
        case 1: // Down
            if(currentFreqDelay < max) currentFreqDelay++;
            else currentFreqDelay = min;
            break;
            
        case 2: // ZigZag
            if(dir) {
                if(currentFreqDelay < max) currentFreqDelay++;
                else dir = 0;
            } else {
                if(currentFreqDelay > min) currentFreqDelay--;
                else dir = 1;
            }
            break;
            
        case 3: // Pulse
            if(++pulseCount >= 500) pulseCount = 0;
            BUZZER = (pulseCount < 50);
            break;
    }
}

void main() {
    // Hardware init
    P1 = P2 = P3 = 0xFF;
    TMOD = 0x01;
    TH0 = 0xFC; TL0 = 0x66;
    ET0 = TR0 = EA = 1;
    
    currentFreqDelay = rangeParams[currentRange][2];
    updateLEDs();

    while(1) {
        if(checkButton(BTN_POWER)) {
            isActive = !isActive;
            if(!isActive) BUZZER = BUZZER_INV = 0;
            updateLEDs();
        }
        
        if(checkButton(BTN_PATTERN)) {
            if(++currentPattern >= 6) currentPattern = 0;
            updateLEDs();
        }
        
        if(checkButton(BTN_SPEED)) {
            if(++currentSpeed >= 3) currentSpeed = 0;
        }
        
        if(checkButton(BTN_RANGE)) {
            currentRange = !currentRange;
            currentFreqDelay = rangeParams[currentRange][2];
            updateLEDs();
        }
        
        if(isActive) {
            generate_tone();
            update_sweep();
        }
    }
}

void Timer0_ISR() interrupt 1 {
    TH0 = 0xFC; TL0 = 0x66;
    static bit blink;
    SPEED_LED = (isActive && (blink = !blink));
}