#include <mcs51/8051.h>  // Include AT89S52 registers
#include <stdint.h>      // For uint16_t

// Simple delay function
void delay_ms(uint16_t ms) {
    uint16_t i, j;
    for(i = 0; i < ms; i++)
        for(j = 0; j < 114; j++);  // ~1ms at 12MHz
}

void main(void) {
    while(1) {
        P1_0 = 0;       // LED ON (assuming active-low)
        delay_ms(500);  // 500ms delay
        
        P1_0 = 1;       // LED OFF
        delay_ms(500);  // 500ms delay
    }
}