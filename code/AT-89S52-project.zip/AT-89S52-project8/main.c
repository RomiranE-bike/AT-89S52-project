/**
 * AT89S52 Buzzer Controller with Selectable Frequency Ranges
 * - 1kHz-10kHz and 18kHz-27kHz operation
 * - Range selection button and LED
 * - Optimized delay calculations
 * - Maintained all LED functionality
 */

#include <reg52.h>
#include <intrins.h>

/*----- Hardware Connections -----*/
// Status LEDs
sbit POWER_LED = P2^0;    // Red
sbit SPEED_LED = P2^1;    // Blue
sbit RANGE_LED = P2^7;    // White (new range indicator)

// Pattern LEDs
sbit UP_LED    = P2^2;    // Green 
sbit DOWN_LED  = P2^3;    // Yellow
sbit ZIGZAG_LED= P2^4;    // Cyan
sbit RAND_LED  = P2^5;    // Purple

sbit BUZZER = P2^6;       // Buzzer

sbit BTN_POWER = P3^2;    // Power
sbit BTN_PATTERN = P3^3;  // Pattern
sbit BTN_SPEED = P3^4;    // Speed
sbit BTN_RANGE = P3^5;    // New Range button

/*----- System State -----*/
bit isActive = 0;
bit lastState_PWR = 1;
bit lastState_PAT = 1;
bit lastState_SPD = 1;
bit lastState_RNG = 1;
bit currentRange = 0;      // 0 = 1-10kHz, 1 = 18-27kHz

/*----- Sound Parameters -----*/
unsigned int currentFreqDelay;
unsigned char currentPattern = 0;
unsigned char currentSpeed = 0;
bit sweepDirection = 0;

// Frequency range parameters
const unsigned int rangeParams[2][3] = {
    // {minDelay, maxDelay, initialDelay} for 1-10kHz
    {9, 250, 100},
    // {minDelay, maxDelay, initialDelay} for 18-27kHz
    {9, 18, 12}
};

/*----- Custom Delay Function -----*/
void delay_ms(unsigned int ms) {
    unsigned int i, j;
    for(i=0; i<ms; i++)
        for(j=0; j<120; j++);  // ~1ms at 12MHz
}

/*----- Timer 0 ISR -----*/
void Timer0_ISR() interrupt 1 {
    static unsigned int msCount = 0;
    TH0 = 0xFC; TL0 = 0x66;
    
    if(isActive) {
        if(++msCount >= 100) {  // 5Hz blink @12MHz
            SPEED_LED = !SPEED_LED;
            msCount = 0;
        }
    } else {
        SPEED_LED = 0;
    }
}

/*----- Update Status LEDs -----*/
void updateStatusLEDs() {
    POWER_LED = isActive;
    UP_LED    = (currentPattern == 0);
    DOWN_LED  = (currentPattern == 1);
    ZIGZAG_LED= (currentPattern == 2);
    RAND_LED  = (currentPattern == 3);
    RANGE_LED = currentRange;  // New range LED
}

/*----- Button Check Functions -----*/
bit checkButton_PWR() {
    bit current = BTN_POWER;
    unsigned char i;
    
    if(current != lastState_PWR) {
        for(i=0; i<20; i++) _nop_();
        if(BTN_POWER == current) {
            lastState_PWR = current;
            return !current;
        }
    }
    return 0;
}

bit checkButton_PAT() {
    bit current = BTN_PATTERN;
    unsigned char i;
    
    if(current != lastState_PAT) {
        for(i=0; i<20; i++) _nop_();
        if(BTN_PATTERN == current) {
            lastState_PAT = current;
            return !current;
        }
    }
    return 0;
}

bit checkButton_SPD() {
    bit current = BTN_SPEED;
    unsigned char i;
    
    if(current != lastState_SPD) {
        for(i=0; i<20; i++) _nop_();
        if(BTN_SPEED == current) {
            lastState_SPD = current;
            return !current;
        }
    }
    return 0;
}

bit checkButton_RNG() {
    bit current = BTN_RANGE;
    unsigned char i;
    
    if(current != lastState_RNG) {
        for(i=0; i<20; i++) _nop_();
        if(BTN_RANGE == current) {
            lastState_RNG = current;
            return !current;
        }
    }
    return 0;
}

/*----- Button Handlers -----*/
void handleButtons() {
    /* Power Button */
    if(checkButton_PWR()) {
        isActive = !isActive;
        if(!isActive) BUZZER = 0;
        updateStatusLEDs();
    }
    
    /* Pattern Button */
    if(checkButton_PAT()) {
        currentPattern = (currentPattern + 1) % 4;
        updateStatusLEDs();
        SPEED_LED = 1; delay_ms(50); SPEED_LED = 0;
    }
    
    /* Speed Button */
    if(checkButton_SPD()) {
        currentSpeed = (currentSpeed + 1) % 5;
        updateStatusLEDs();
    }
    
    /* Range Button - NEW */
    if(checkButton_RNG()) {
        currentRange = !currentRange;
        // Reset frequency to middle of new range
        currentFreqDelay = rangeParams[currentRange][2];
        updateStatusLEDs();
    }
}

/*----- Tone Generation -----*/
void generate_tone() {
    unsigned int i;
    BUZZER = !BUZZER;
    for(i=0; i<currentFreqDelay; i++) _nop_();
}

/*----- Sweep Patterns -----*/
void update_sweep() {
    static unsigned char speedSteps[5] = {1, 2, 3, 5, 8};
    unsigned int minDelay = rangeParams[currentRange][0];
    unsigned int maxDelay = rangeParams[currentRange][1];
    
    switch(currentPattern) {
        case 0: // Up Sweep (low?high freq)
            if(currentFreqDelay > minDelay) 
                currentFreqDelay -= speedSteps[currentSpeed];
            else 
                currentFreqDelay = maxDelay;
            break;
            
        case 1: // Down Sweep (high?low freq)
            if(currentFreqDelay < maxDelay) 
                currentFreqDelay += speedSteps[currentSpeed];
            else 
                currentFreqDelay = minDelay;
            break;
            
        case 2: // Zig-Zag
            if(sweepDirection) {
                if(currentFreqDelay < maxDelay) 
                    currentFreqDelay += speedSteps[currentSpeed];
                else 
                    sweepDirection = 0;
            } else {
                if(currentFreqDelay > minDelay) 
                    currentFreqDelay -= speedSteps[currentSpeed];
                else 
                    sweepDirection = 1;
            }
            break;
            
        case 3: // Random
            currentFreqDelay = minDelay + (currentFreqDelay % (maxDelay-minDelay));
            break;
    }
}

void main() {
    /* Initialize */
    POWER_LED = SPEED_LED = UP_LED = DOWN_LED = ZIGZAG_LED = RAND_LED = RANGE_LED = 0;
    TMOD = 0x01;
    TH0 = 0xFC; TL0 = 0x66;
    ET0 = TR0 = EA = 1;
    
    // Set initial frequency range (5-10kHz)
    currentRange = 0;
    currentFreqDelay = rangeParams[currentRange][2];
    
    /* Main Loop */
    while(1) {
        handleButtons();
        if(isActive) {
            generate_tone();
            update_sweep();
        }
    }
}