                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.2.0 #13081 (MINGW32)
                                      4 ;--------------------------------------------------------
                                      5 	.module AT89S52_Buzzer
                                      6 	.optsdcc -mmcs51 --model-small
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _speedSteps
                                     12 	.globl _rangeParams
                                     13 	.globl _main
                                     14 	.globl _Timer0_ISR
                                     15 	.globl _BTN_RANGE
                                     16 	.globl _BTN_SPEED
                                     17 	.globl _BTN_PATTERN
                                     18 	.globl _BTN_POWER
                                     19 	.globl _BUZZER_COMP
                                     20 	.globl _BUZZER
                                     21 	.globl _WALK_LED
                                     22 	.globl _CHIRP_LED
                                     23 	.globl _SIREN_LED
                                     24 	.globl _HEART_LED
                                     25 	.globl _STEP_LED
                                     26 	.globl _TRIANGLE_LED
                                     27 	.globl _PULSE_LED
                                     28 	.globl _RAND_LED
                                     29 	.globl _ZIGZAG_LED
                                     30 	.globl _DOWN_LED
                                     31 	.globl _UP_LED
                                     32 	.globl _RANGE_LED
                                     33 	.globl _SPEED_LED
                                     34 	.globl _CY
                                     35 	.globl _AC
                                     36 	.globl _F0
                                     37 	.globl _RS1
                                     38 	.globl _RS0
                                     39 	.globl _OV
                                     40 	.globl _F1
                                     41 	.globl _P
                                     42 	.globl _PS
                                     43 	.globl _PT1
                                     44 	.globl _PX1
                                     45 	.globl _PT0
                                     46 	.globl _PX0
                                     47 	.globl _RD
                                     48 	.globl _WR
                                     49 	.globl _T1
                                     50 	.globl _T0
                                     51 	.globl _INT1
                                     52 	.globl _INT0
                                     53 	.globl _TXD
                                     54 	.globl _RXD
                                     55 	.globl _P3_7
                                     56 	.globl _P3_6
                                     57 	.globl _P3_5
                                     58 	.globl _P3_4
                                     59 	.globl _P3_3
                                     60 	.globl _P3_2
                                     61 	.globl _P3_1
                                     62 	.globl _P3_0
                                     63 	.globl _EA
                                     64 	.globl _ES
                                     65 	.globl _ET1
                                     66 	.globl _EX1
                                     67 	.globl _ET0
                                     68 	.globl _EX0
                                     69 	.globl _P2_7
                                     70 	.globl _P2_6
                                     71 	.globl _P2_5
                                     72 	.globl _P2_4
                                     73 	.globl _P2_3
                                     74 	.globl _P2_2
                                     75 	.globl _P2_1
                                     76 	.globl _P2_0
                                     77 	.globl _SM0
                                     78 	.globl _SM1
                                     79 	.globl _SM2
                                     80 	.globl _REN
                                     81 	.globl _TB8
                                     82 	.globl _RB8
                                     83 	.globl _TI
                                     84 	.globl _RI
                                     85 	.globl _P1_7
                                     86 	.globl _P1_6
                                     87 	.globl _P1_5
                                     88 	.globl _P1_4
                                     89 	.globl _P1_3
                                     90 	.globl _P1_2
                                     91 	.globl _P1_1
                                     92 	.globl _P1_0
                                     93 	.globl _TF1
                                     94 	.globl _TR1
                                     95 	.globl _TF0
                                     96 	.globl _TR0
                                     97 	.globl _IE1
                                     98 	.globl _IT1
                                     99 	.globl _IE0
                                    100 	.globl _IT0
                                    101 	.globl _P0_7
                                    102 	.globl _P0_6
                                    103 	.globl _P0_5
                                    104 	.globl _P0_4
                                    105 	.globl _P0_3
                                    106 	.globl _P0_2
                                    107 	.globl _P0_1
                                    108 	.globl _P0_0
                                    109 	.globl _B
                                    110 	.globl _ACC
                                    111 	.globl _PSW
                                    112 	.globl _IP
                                    113 	.globl _P3
                                    114 	.globl _IE
                                    115 	.globl _P2
                                    116 	.globl _SBUF
                                    117 	.globl _SCON
                                    118 	.globl _P1
                                    119 	.globl _TH1
                                    120 	.globl _TH0
                                    121 	.globl _TL1
                                    122 	.globl _TL0
                                    123 	.globl _TMOD
                                    124 	.globl _TCON
                                    125 	.globl _PCON
                                    126 	.globl _DPH
                                    127 	.globl _DPL
                                    128 	.globl _SP
                                    129 	.globl _P0
                                    130 	.globl _sweepDirection
                                    131 	.globl _currentRange
                                    132 	.globl _isActive
                                    133 	.globl _currentFreqDelay
                                    134 	.globl _currentSpeed
                                    135 	.globl _currentPattern
                                    136 	.globl _delay_ms
                                    137 	.globl _updateStatusLEDs
                                    138 	.globl _simple_rand
                                    139 	.globl _checkButton_PWR
                                    140 	.globl _checkButton_PAT
                                    141 	.globl _checkButton_SPD
                                    142 	.globl _checkButton_RNG
                                    143 	.globl _generate_tone
                                    144 	.globl _update_sweep
                                    145 ;--------------------------------------------------------
                                    146 ; special function registers
                                    147 ;--------------------------------------------------------
                                    148 	.area RSEG    (ABS,DATA)
      000000                        149 	.org 0x0000
                           000080   150 _P0	=	0x0080
                           000081   151 _SP	=	0x0081
                           000082   152 _DPL	=	0x0082
                           000083   153 _DPH	=	0x0083
                           000087   154 _PCON	=	0x0087
                           000088   155 _TCON	=	0x0088
                           000089   156 _TMOD	=	0x0089
                           00008A   157 _TL0	=	0x008a
                           00008B   158 _TL1	=	0x008b
                           00008C   159 _TH0	=	0x008c
                           00008D   160 _TH1	=	0x008d
                           000090   161 _P1	=	0x0090
                           000098   162 _SCON	=	0x0098
                           000099   163 _SBUF	=	0x0099
                           0000A0   164 _P2	=	0x00a0
                           0000A8   165 _IE	=	0x00a8
                           0000B0   166 _P3	=	0x00b0
                           0000B8   167 _IP	=	0x00b8
                           0000D0   168 _PSW	=	0x00d0
                           0000E0   169 _ACC	=	0x00e0
                           0000F0   170 _B	=	0x00f0
                                    171 ;--------------------------------------------------------
                                    172 ; special function bits
                                    173 ;--------------------------------------------------------
                                    174 	.area RSEG    (ABS,DATA)
      000000                        175 	.org 0x0000
                           000080   176 _P0_0	=	0x0080
                           000081   177 _P0_1	=	0x0081
                           000082   178 _P0_2	=	0x0082
                           000083   179 _P0_3	=	0x0083
                           000084   180 _P0_4	=	0x0084
                           000085   181 _P0_5	=	0x0085
                           000086   182 _P0_6	=	0x0086
                           000087   183 _P0_7	=	0x0087
                           000088   184 _IT0	=	0x0088
                           000089   185 _IE0	=	0x0089
                           00008A   186 _IT1	=	0x008a
                           00008B   187 _IE1	=	0x008b
                           00008C   188 _TR0	=	0x008c
                           00008D   189 _TF0	=	0x008d
                           00008E   190 _TR1	=	0x008e
                           00008F   191 _TF1	=	0x008f
                           000090   192 _P1_0	=	0x0090
                           000091   193 _P1_1	=	0x0091
                           000092   194 _P1_2	=	0x0092
                           000093   195 _P1_3	=	0x0093
                           000094   196 _P1_4	=	0x0094
                           000095   197 _P1_5	=	0x0095
                           000096   198 _P1_6	=	0x0096
                           000097   199 _P1_7	=	0x0097
                           000098   200 _RI	=	0x0098
                           000099   201 _TI	=	0x0099
                           00009A   202 _RB8	=	0x009a
                           00009B   203 _TB8	=	0x009b
                           00009C   204 _REN	=	0x009c
                           00009D   205 _SM2	=	0x009d
                           00009E   206 _SM1	=	0x009e
                           00009F   207 _SM0	=	0x009f
                           0000A0   208 _P2_0	=	0x00a0
                           0000A1   209 _P2_1	=	0x00a1
                           0000A2   210 _P2_2	=	0x00a2
                           0000A3   211 _P2_3	=	0x00a3
                           0000A4   212 _P2_4	=	0x00a4
                           0000A5   213 _P2_5	=	0x00a5
                           0000A6   214 _P2_6	=	0x00a6
                           0000A7   215 _P2_7	=	0x00a7
                           0000A8   216 _EX0	=	0x00a8
                           0000A9   217 _ET0	=	0x00a9
                           0000AA   218 _EX1	=	0x00aa
                           0000AB   219 _ET1	=	0x00ab
                           0000AC   220 _ES	=	0x00ac
                           0000AF   221 _EA	=	0x00af
                           0000B0   222 _P3_0	=	0x00b0
                           0000B1   223 _P3_1	=	0x00b1
                           0000B2   224 _P3_2	=	0x00b2
                           0000B3   225 _P3_3	=	0x00b3
                           0000B4   226 _P3_4	=	0x00b4
                           0000B5   227 _P3_5	=	0x00b5
                           0000B6   228 _P3_6	=	0x00b6
                           0000B7   229 _P3_7	=	0x00b7
                           0000B0   230 _RXD	=	0x00b0
                           0000B1   231 _TXD	=	0x00b1
                           0000B2   232 _INT0	=	0x00b2
                           0000B3   233 _INT1	=	0x00b3
                           0000B4   234 _T0	=	0x00b4
                           0000B5   235 _T1	=	0x00b5
                           0000B6   236 _WR	=	0x00b6
                           0000B7   237 _RD	=	0x00b7
                           0000B8   238 _PX0	=	0x00b8
                           0000B9   239 _PT0	=	0x00b9
                           0000BA   240 _PX1	=	0x00ba
                           0000BB   241 _PT1	=	0x00bb
                           0000BC   242 _PS	=	0x00bc
                           0000D0   243 _P	=	0x00d0
                           0000D1   244 _F1	=	0x00d1
                           0000D2   245 _OV	=	0x00d2
                           0000D3   246 _RS0	=	0x00d3
                           0000D4   247 _RS1	=	0x00d4
                           0000D5   248 _F0	=	0x00d5
                           0000D6   249 _AC	=	0x00d6
                           0000D7   250 _CY	=	0x00d7
                           0000A6   251 _SPEED_LED	=	0x00a6
                           0000A7   252 _RANGE_LED	=	0x00a7
                           0000A0   253 _UP_LED	=	0x00a0
                           0000A1   254 _DOWN_LED	=	0x00a1
                           0000A2   255 _ZIGZAG_LED	=	0x00a2
                           0000A3   256 _RAND_LED	=	0x00a3
                           0000A4   257 _PULSE_LED	=	0x00a4
                           000095   258 _TRIANGLE_LED	=	0x0095
                           0000A0   259 _STEP_LED	=	0x00a0
                           0000A1   260 _HEART_LED	=	0x00a1
                           0000A2   261 _SIREN_LED	=	0x00a2
                           0000A3   262 _CHIRP_LED	=	0x00a3
                           0000A4   263 _WALK_LED	=	0x00a4
                           0000B0   264 _BUZZER	=	0x00b0
                           0000B1   265 _BUZZER_COMP	=	0x00b1
                           0000B2   266 _BTN_POWER	=	0x00b2
                           0000B3   267 _BTN_PATTERN	=	0x00b3
                           0000B4   268 _BTN_SPEED	=	0x00b4
                           0000B5   269 _BTN_RANGE	=	0x00b5
                                    270 ;--------------------------------------------------------
                                    271 ; overlayable register banks
                                    272 ;--------------------------------------------------------
                                    273 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        274 	.ds 8
                                    275 ;--------------------------------------------------------
                                    276 ; overlayable bit register bank
                                    277 ;--------------------------------------------------------
                                    278 	.area BIT_BANK	(REL,OVR,DATA)
      000021                        279 bits:
      000021                        280 	.ds 1
                           008000   281 	b0 = bits[0]
                           008100   282 	b1 = bits[1]
                           008200   283 	b2 = bits[2]
                           008300   284 	b3 = bits[3]
                           008400   285 	b4 = bits[4]
                           008500   286 	b5 = bits[5]
                           008600   287 	b6 = bits[6]
                           008700   288 	b7 = bits[7]
                                    289 ;--------------------------------------------------------
                                    290 ; internal ram data
                                    291 ;--------------------------------------------------------
                                    292 	.area DSEG    (DATA)
      000022                        293 _currentPattern::
      000022                        294 	.ds 1
      000023                        295 _currentSpeed::
      000023                        296 	.ds 1
      000024                        297 _currentFreqDelay::
      000024                        298 	.ds 2
      000026                        299 _Timer0_ISR_msCount_65536_15:
      000026                        300 	.ds 2
      000028                        301 _simple_rand_seed_65536_20:
      000028                        302 	.ds 2
      00002A                        303 _generate_tone_toneCounter_65536_33:
      00002A                        304 	.ds 2
      00002C                        305 _update_sweep_pulseCount_65536_35:
      00002C                        306 	.ds 2
      00002E                        307 _update_sweep_stepCount_65536_35:
      00002E                        308 	.ds 2
      000030                        309 _update_sweep_freqStep_65536_35:
      000030                        310 	.ds 2
      000032                        311 _update_sweep_hbCount_65536_35:
      000032                        312 	.ds 2
      000034                        313 _update_sweep_sirenCount_65536_35:
      000034                        314 	.ds 2
      000036                        315 _update_sweep_chirpState_65536_35:
      000036                        316 	.ds 1
      000037                        317 _update_sweep_chirpCount_65536_35:
      000037                        318 	.ds 2
      000039                        319 _update_sweep_walkCount_65536_35:
      000039                        320 	.ds 2
                                    321 ;--------------------------------------------------------
                                    322 ; overlayable items in internal ram
                                    323 ;--------------------------------------------------------
                                    324 ;--------------------------------------------------------
                                    325 ; Stack segment in internal ram
                                    326 ;--------------------------------------------------------
                                    327 	.area	SSEG
      00003B                        328 __start__stack:
      00003B                        329 	.ds	1
                                    330 
                                    331 ;--------------------------------------------------------
                                    332 ; indirectly addressable internal ram data
                                    333 ;--------------------------------------------------------
                                    334 	.area ISEG    (DATA)
                                    335 ;--------------------------------------------------------
                                    336 ; absolute internal ram data
                                    337 ;--------------------------------------------------------
                                    338 	.area IABS    (ABS,DATA)
                                    339 	.area IABS    (ABS,DATA)
                                    340 ;--------------------------------------------------------
                                    341 ; bit data
                                    342 ;--------------------------------------------------------
                                    343 	.area BSEG    (BIT)
      000000                        344 _isActive::
      000000                        345 	.ds 1
      000001                        346 _currentRange::
      000001                        347 	.ds 1
      000002                        348 _sweepDirection::
      000002                        349 	.ds 1
      000003                        350 _checkButton_PWR_lastState_65536_21:
      000003                        351 	.ds 1
      000004                        352 _checkButton_PAT_lastState_65536_24:
      000004                        353 	.ds 1
      000005                        354 _checkButton_SPD_lastState_65536_27:
      000005                        355 	.ds 1
      000006                        356 _checkButton_RNG_lastState_65536_30:
      000006                        357 	.ds 1
                                    358 ;--------------------------------------------------------
                                    359 ; paged external ram data
                                    360 ;--------------------------------------------------------
                                    361 	.area PSEG    (PAG,XDATA)
                                    362 ;--------------------------------------------------------
                                    363 ; external ram data
                                    364 ;--------------------------------------------------------
                                    365 	.area XSEG    (XDATA)
                                    366 ;--------------------------------------------------------
                                    367 ; absolute external ram data
                                    368 ;--------------------------------------------------------
                                    369 	.area XABS    (ABS,XDATA)
                                    370 ;--------------------------------------------------------
                                    371 ; external initialized ram data
                                    372 ;--------------------------------------------------------
                                    373 	.area XISEG   (XDATA)
                                    374 	.area HOME    (CODE)
                                    375 	.area GSINIT0 (CODE)
                                    376 	.area GSINIT1 (CODE)
                                    377 	.area GSINIT2 (CODE)
                                    378 	.area GSINIT3 (CODE)
                                    379 	.area GSINIT4 (CODE)
                                    380 	.area GSINIT5 (CODE)
                                    381 	.area GSINIT  (CODE)
                                    382 	.area GSFINAL (CODE)
                                    383 	.area CSEG    (CODE)
                                    384 ;--------------------------------------------------------
                                    385 ; interrupt vector
                                    386 ;--------------------------------------------------------
                                    387 	.area HOME    (CODE)
      000000                        388 __interrupt_vect:
      000000 02 00 11         [24]  389 	ljmp	__sdcc_gsinit_startup
      000003 32               [24]  390 	reti
      000004                        391 	.ds	7
      00000B 02 00 D5         [24]  392 	ljmp	_Timer0_ISR
                                    393 ;--------------------------------------------------------
                                    394 ; global & static initialisations
                                    395 ;--------------------------------------------------------
                                    396 	.area HOME    (CODE)
                                    397 	.area GSINIT  (CODE)
                                    398 	.area GSFINAL (CODE)
                                    399 	.area GSINIT  (CODE)
                                    400 	.globl __sdcc_gsinit_startup
                                    401 	.globl __sdcc_program_startup
                                    402 	.globl __start__stack
                                    403 	.globl __mcs51_genXINIT
                                    404 	.globl __mcs51_genXRAMCLEAR
                                    405 	.globl __mcs51_genRAMCLEAR
                                    406 ;------------------------------------------------------------
                                    407 ;Allocation info for local variables in function 'Timer0_ISR'
                                    408 ;------------------------------------------------------------
                                    409 ;msCount                   Allocated with name '_Timer0_ISR_msCount_65536_15'
                                    410 ;------------------------------------------------------------
                                    411 ;	AT89S52-Buzzer.c:82: static uint16_t msCount = 0;
      00006A E4               [12]  412 	clr	a
      00006B F5 26            [12]  413 	mov	_Timer0_ISR_msCount_65536_15,a
      00006D F5 27            [12]  414 	mov	(_Timer0_ISR_msCount_65536_15 + 1),a
                                    415 ;------------------------------------------------------------
                                    416 ;Allocation info for local variables in function 'simple_rand'
                                    417 ;------------------------------------------------------------
                                    418 ;seed                      Allocated with name '_simple_rand_seed_65536_20'
                                    419 ;------------------------------------------------------------
                                    420 ;	AT89S52-Buzzer.c:117: static uint16_t seed = 12345;
      00006F 75 28 39         [24]  421 	mov	_simple_rand_seed_65536_20,#0x39
      000072 75 29 30         [24]  422 	mov	(_simple_rand_seed_65536_20 + 1),#0x30
                                    423 ;------------------------------------------------------------
                                    424 ;Allocation info for local variables in function 'checkButton_PWR'
                                    425 ;------------------------------------------------------------
                                    426 ;current                   Allocated to registers b0 
                                    427 ;------------------------------------------------------------
                                    428 ;	AT89S52-Buzzer.c:124: static __bit lastState = 1;
                                    429 ;	assignBit
      000075 D2 03            [12]  430 	setb	_checkButton_PWR_lastState_65536_21
                                    431 ;------------------------------------------------------------
                                    432 ;Allocation info for local variables in function 'checkButton_PAT'
                                    433 ;------------------------------------------------------------
                                    434 ;current                   Allocated to registers b0 
                                    435 ;------------------------------------------------------------
                                    436 ;	AT89S52-Buzzer.c:137: static __bit lastState = 1;
                                    437 ;	assignBit
      000077 D2 04            [12]  438 	setb	_checkButton_PAT_lastState_65536_24
                                    439 ;------------------------------------------------------------
                                    440 ;Allocation info for local variables in function 'checkButton_SPD'
                                    441 ;------------------------------------------------------------
                                    442 ;current                   Allocated to registers b0 
                                    443 ;------------------------------------------------------------
                                    444 ;	AT89S52-Buzzer.c:150: static __bit lastState = 1;
                                    445 ;	assignBit
      000079 D2 05            [12]  446 	setb	_checkButton_SPD_lastState_65536_27
                                    447 ;------------------------------------------------------------
                                    448 ;Allocation info for local variables in function 'checkButton_RNG'
                                    449 ;------------------------------------------------------------
                                    450 ;current                   Allocated to registers b0 
                                    451 ;------------------------------------------------------------
                                    452 ;	AT89S52-Buzzer.c:163: static __bit lastState = 1;
                                    453 ;	assignBit
      00007B D2 06            [12]  454 	setb	_checkButton_RNG_lastState_65536_30
                                    455 ;------------------------------------------------------------
                                    456 ;Allocation info for local variables in function 'generate_tone'
                                    457 ;------------------------------------------------------------
                                    458 ;toneCounter               Allocated with name '_generate_tone_toneCounter_65536_33'
                                    459 ;------------------------------------------------------------
                                    460 ;	AT89S52-Buzzer.c:177: static uint16_t toneCounter = 0;
      00007D E4               [12]  461 	clr	a
      00007E F5 2A            [12]  462 	mov	_generate_tone_toneCounter_65536_33,a
      000080 F5 2B            [12]  463 	mov	(_generate_tone_toneCounter_65536_33 + 1),a
                                    464 ;------------------------------------------------------------
                                    465 ;Allocation info for local variables in function 'update_sweep'
                                    466 ;------------------------------------------------------------
                                    467 ;minDelay                  Allocated to registers r4 r5 
                                    468 ;maxDelay                  Allocated to stack - _bp +1
                                    469 ;sloc0                     Allocated to stack - _bp +5
                                    470 ;sloc1                     Allocated to stack - _bp +7
                                    471 ;pulseCount                Allocated with name '_update_sweep_pulseCount_65536_35'
                                    472 ;stepCount                 Allocated with name '_update_sweep_stepCount_65536_35'
                                    473 ;freqStep                  Allocated with name '_update_sweep_freqStep_65536_35'
                                    474 ;hbCount                   Allocated with name '_update_sweep_hbCount_65536_35'
                                    475 ;sirenCount                Allocated with name '_update_sweep_sirenCount_65536_35'
                                    476 ;chirpState                Allocated with name '_update_sweep_chirpState_65536_35'
                                    477 ;chirpCount                Allocated with name '_update_sweep_chirpCount_65536_35'
                                    478 ;walkCount                 Allocated with name '_update_sweep_walkCount_65536_35'
                                    479 ;------------------------------------------------------------
                                    480 ;	AT89S52-Buzzer.c:191: static uint16_t pulseCount = 0;       // For pulse pattern
      000082 E4               [12]  481 	clr	a
      000083 F5 2C            [12]  482 	mov	_update_sweep_pulseCount_65536_35,a
      000085 F5 2D            [12]  483 	mov	(_update_sweep_pulseCount_65536_35 + 1),a
                                    484 ;	AT89S52-Buzzer.c:192: static uint16_t stepCount = 0;        // For stepped pattern
      000087 F5 2E            [12]  485 	mov	_update_sweep_stepCount_65536_35,a
      000089 F5 2F            [12]  486 	mov	(_update_sweep_stepCount_65536_35 + 1),a
                                    487 ;	AT89S52-Buzzer.c:193: static int16_t freqStep = 1;          // For triangle pattern
      00008B 75 30 01         [24]  488 	mov	_update_sweep_freqStep_65536_35,#0x01
                                    489 ;	1-genFromRTrack replaced	mov	(_update_sweep_freqStep_65536_35 + 1),#0x00
      00008E F5 31            [12]  490 	mov	(_update_sweep_freqStep_65536_35 + 1),a
                                    491 ;	AT89S52-Buzzer.c:194: static uint16_t hbCount = 0;          // For heartbeat pattern
      000090 F5 32            [12]  492 	mov	_update_sweep_hbCount_65536_35,a
      000092 F5 33            [12]  493 	mov	(_update_sweep_hbCount_65536_35 + 1),a
                                    494 ;	AT89S52-Buzzer.c:195: static uint16_t sirenCount = 0;       // For siren pattern
      000094 F5 34            [12]  495 	mov	_update_sweep_sirenCount_65536_35,a
      000096 F5 35            [12]  496 	mov	(_update_sweep_sirenCount_65536_35 + 1),a
                                    497 ;	AT89S52-Buzzer.c:196: static uint8_t chirpState = 0;        // For chirps pattern
                                    498 ;	1-genFromRTrack replaced	mov	_update_sweep_chirpState_65536_35,#0x00
      000098 F5 36            [12]  499 	mov	_update_sweep_chirpState_65536_35,a
                                    500 ;	AT89S52-Buzzer.c:197: static uint16_t chirpCount = 0;       // For chirps pattern
      00009A F5 37            [12]  501 	mov	_update_sweep_chirpCount_65536_35,a
      00009C F5 38            [12]  502 	mov	(_update_sweep_chirpCount_65536_35 + 1),a
                                    503 ;	AT89S52-Buzzer.c:198: static uint16_t walkCount = 0;        // For random walk pattern
      00009E F5 39            [12]  504 	mov	_update_sweep_walkCount_65536_35,a
      0000A0 F5 3A            [12]  505 	mov	(_update_sweep_walkCount_65536_35 + 1),a
                                    506 ;	AT89S52-Buzzer.c:45: uint8_t currentPattern = 0;        // Current pattern (0-10)
      0000A2 75 22 00         [24]  507 	mov	_currentPattern,#0x00
                                    508 ;	AT89S52-Buzzer.c:46: uint8_t currentSpeed = 0;          // Speed setting (0-4)
      0000A5 75 23 00         [24]  509 	mov	_currentSpeed,#0x00
                                    510 ;	AT89S52-Buzzer.c:43: __bit isActive = 0;                // Power state
                                    511 ;	assignBit
      0000A8 C2 00            [12]  512 	clr	_isActive
                                    513 ;	AT89S52-Buzzer.c:44: __bit currentRange = 0;            // 0=5-10kHz, 1=18-27kHz
                                    514 ;	assignBit
      0000AA C2 01            [12]  515 	clr	_currentRange
                                    516 ;	AT89S52-Buzzer.c:47: __bit sweepDirection = 0;          // For zigzag pattern
                                    517 ;	assignBit
      0000AC C2 02            [12]  518 	clr	_sweepDirection
                                    519 	.area GSFINAL (CODE)
      0000AE 02 00 0E         [24]  520 	ljmp	__sdcc_program_startup
                                    521 ;--------------------------------------------------------
                                    522 ; Home
                                    523 ;--------------------------------------------------------
                                    524 	.area HOME    (CODE)
                                    525 	.area HOME    (CODE)
      00000E                        526 __sdcc_program_startup:
      00000E 02 07 0A         [24]  527 	ljmp	_main
                                    528 ;	return from main will return to caller
                                    529 ;--------------------------------------------------------
                                    530 ; code
                                    531 ;--------------------------------------------------------
                                    532 	.area CSEG    (CODE)
                                    533 ;------------------------------------------------------------
                                    534 ;Allocation info for local variables in function 'delay_ms'
                                    535 ;------------------------------------------------------------
                                    536 ;ms                        Allocated to registers r6 r7 
                                    537 ;i                         Allocated to registers r4 r5 
                                    538 ;j                         Allocated to registers r2 r3 
                                    539 ;------------------------------------------------------------
                                    540 ;	AT89S52-Buzzer.c:74: void delay_ms(uint16_t ms) {
                                    541 ;	-----------------------------------------
                                    542 ;	 function delay_ms
                                    543 ;	-----------------------------------------
      0000B1                        544 _delay_ms:
                           000007   545 	ar7 = 0x07
                           000006   546 	ar6 = 0x06
                           000005   547 	ar5 = 0x05
                           000004   548 	ar4 = 0x04
                           000003   549 	ar3 = 0x03
                           000002   550 	ar2 = 0x02
                           000001   551 	ar1 = 0x01
                           000000   552 	ar0 = 0x00
      0000B1 AE 82            [24]  553 	mov	r6,dpl
      0000B3 AF 83            [24]  554 	mov	r7,dph
                                    555 ;	AT89S52-Buzzer.c:76: for(i=0; i<ms; i++)
      0000B5 7C 00            [12]  556 	mov	r4,#0x00
      0000B7 7D 00            [12]  557 	mov	r5,#0x00
      0000B9                        558 00107$:
      0000B9 C3               [12]  559 	clr	c
      0000BA EC               [12]  560 	mov	a,r4
      0000BB 9E               [12]  561 	subb	a,r6
      0000BC ED               [12]  562 	mov	a,r5
      0000BD 9F               [12]  563 	subb	a,r7
      0000BE 50 14            [24]  564 	jnc	00109$
                                    565 ;	AT89S52-Buzzer.c:77: for(j=0; j<120; j++);  // ~1ms at 12MHz
      0000C0 7A 78            [12]  566 	mov	r2,#0x78
      0000C2 7B 00            [12]  567 	mov	r3,#0x00
      0000C4                        568 00105$:
      0000C4 1A               [12]  569 	dec	r2
      0000C5 BA FF 01         [24]  570 	cjne	r2,#0xff,00130$
      0000C8 1B               [12]  571 	dec	r3
      0000C9                        572 00130$:
      0000C9 EA               [12]  573 	mov	a,r2
      0000CA 4B               [12]  574 	orl	a,r3
      0000CB 70 F7            [24]  575 	jnz	00105$
                                    576 ;	AT89S52-Buzzer.c:76: for(i=0; i<ms; i++)
      0000CD 0C               [12]  577 	inc	r4
      0000CE BC 00 E8         [24]  578 	cjne	r4,#0x00,00107$
      0000D1 0D               [12]  579 	inc	r5
      0000D2 80 E5            [24]  580 	sjmp	00107$
      0000D4                        581 00109$:
                                    582 ;	AT89S52-Buzzer.c:78: }
      0000D4 22               [24]  583 	ret
                                    584 ;------------------------------------------------------------
                                    585 ;Allocation info for local variables in function 'Timer0_ISR'
                                    586 ;------------------------------------------------------------
                                    587 ;msCount                   Allocated with name '_Timer0_ISR_msCount_65536_15'
                                    588 ;------------------------------------------------------------
                                    589 ;	AT89S52-Buzzer.c:81: void Timer0_ISR() __interrupt(1) {
                                    590 ;	-----------------------------------------
                                    591 ;	 function Timer0_ISR
                                    592 ;	-----------------------------------------
      0000D5                        593 _Timer0_ISR:
      0000D5 C0 E0            [24]  594 	push	acc
      0000D7 C0 07            [24]  595 	push	ar7
      0000D9 C0 06            [24]  596 	push	ar6
      0000DB C0 D0            [24]  597 	push	psw
      0000DD 75 D0 00         [24]  598 	mov	psw,#0x00
                                    599 ;	AT89S52-Buzzer.c:83: TH0 = 0xFC; TL0 = 0x66;  // Reload for 1ms
      0000E0 75 8C FC         [24]  600 	mov	_TH0,#0xfc
      0000E3 75 8A 66         [24]  601 	mov	_TL0,#0x66
                                    602 ;	AT89S52-Buzzer.c:85: if(isActive) {
      0000E6 30 00 1E         [24]  603 	jnb	_isActive,00104$
                                    604 ;	AT89S52-Buzzer.c:86: if(++msCount >= 100) {  // 5Hz blink
      0000E9 05 26            [12]  605 	inc	_Timer0_ISR_msCount_65536_15
      0000EB E4               [12]  606 	clr	a
      0000EC B5 26 02         [24]  607 	cjne	a,_Timer0_ISR_msCount_65536_15,00117$
      0000EF 05 27            [12]  608 	inc	(_Timer0_ISR_msCount_65536_15 + 1)
      0000F1                        609 00117$:
      0000F1 AE 26            [24]  610 	mov	r6,_Timer0_ISR_msCount_65536_15
      0000F3 AF 27            [24]  611 	mov	r7,(_Timer0_ISR_msCount_65536_15 + 1)
      0000F5 C3               [12]  612 	clr	c
      0000F6 EE               [12]  613 	mov	a,r6
      0000F7 94 64            [12]  614 	subb	a,#0x64
      0000F9 EF               [12]  615 	mov	a,r7
      0000FA 94 00            [12]  616 	subb	a,#0x00
      0000FC 40 0B            [24]  617 	jc	00106$
                                    618 ;	AT89S52-Buzzer.c:87: SPEED_LED = !SPEED_LED;
      0000FE B2 A6            [12]  619 	cpl	_SPEED_LED
                                    620 ;	AT89S52-Buzzer.c:88: msCount = 0;
      000100 E4               [12]  621 	clr	a
      000101 F5 26            [12]  622 	mov	_Timer0_ISR_msCount_65536_15,a
      000103 F5 27            [12]  623 	mov	(_Timer0_ISR_msCount_65536_15 + 1),a
      000105 80 02            [24]  624 	sjmp	00106$
      000107                        625 00104$:
                                    626 ;	AT89S52-Buzzer.c:91: SPEED_LED = 1;  // Turn off (active low)
                                    627 ;	assignBit
      000107 D2 A6            [12]  628 	setb	_SPEED_LED
      000109                        629 00106$:
                                    630 ;	AT89S52-Buzzer.c:93: }
      000109 D0 D0            [24]  631 	pop	psw
      00010B D0 06            [24]  632 	pop	ar6
      00010D D0 07            [24]  633 	pop	ar7
      00010F D0 E0            [24]  634 	pop	acc
      000111 32               [24]  635 	reti
                                    636 ;	eliminated unneeded push/pop dpl
                                    637 ;	eliminated unneeded push/pop dph
                                    638 ;	eliminated unneeded push/pop b
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'updateStatusLEDs'
                                    641 ;------------------------------------------------------------
                                    642 ;	AT89S52-Buzzer.c:96: void updateStatusLEDs() {
                                    643 ;	-----------------------------------------
                                    644 ;	 function updateStatusLEDs
                                    645 ;	-----------------------------------------
      000112                        646 _updateStatusLEDs:
                                    647 ;	AT89S52-Buzzer.c:99: RANGE_LED = !currentRange;
      000112 A2 01            [12]  648 	mov	c,_currentRange
      000114 B3               [12]  649 	cpl	c
      000115 92 A7            [24]  650 	mov	_RANGE_LED,c
                                    651 ;	AT89S52-Buzzer.c:102: UP_LED      = (currentPattern != 0);
      000117 E5 22            [12]  652 	mov	a,_currentPattern
      000119 B4 01 00         [24]  653 	cjne	a,#0x01,00103$
      00011C                        654 00103$:
      00011C B3               [12]  655 	cpl	c
      00011D 92 08            [24]  656 	mov	b0,c
      00011F E4               [12]  657 	clr	a
      000120 33               [12]  658 	rlc	a
      000121 24 FF            [12]  659 	add	a,#0xff
      000123 92 A0            [24]  660 	mov	_UP_LED,c
                                    661 ;	AT89S52-Buzzer.c:103: DOWN_LED    = (currentPattern != 1);
      000125 74 01            [12]  662 	mov	a,#0x01
      000127 B5 22 03         [24]  663 	cjne	a,_currentPattern,00104$
      00012A D3               [12]  664 	setb	c
      00012B 80 01            [24]  665 	sjmp	00105$
      00012D                        666 00104$:
      00012D C3               [12]  667 	clr	c
      00012E                        668 00105$:
      00012E B3               [12]  669 	cpl	c
      00012F 92 08            [24]  670 	mov	b0,c
      000131 E4               [12]  671 	clr	a
      000132 33               [12]  672 	rlc	a
      000133 24 FF            [12]  673 	add	a,#0xff
      000135 92 A1            [24]  674 	mov	_DOWN_LED,c
                                    675 ;	AT89S52-Buzzer.c:104: ZIGZAG_LED  = (currentPattern != 2);
      000137 74 02            [12]  676 	mov	a,#0x02
      000139 B5 22 03         [24]  677 	cjne	a,_currentPattern,00106$
      00013C D3               [12]  678 	setb	c
      00013D 80 01            [24]  679 	sjmp	00107$
      00013F                        680 00106$:
      00013F C3               [12]  681 	clr	c
      000140                        682 00107$:
      000140 B3               [12]  683 	cpl	c
      000141 92 08            [24]  684 	mov	b0,c
      000143 E4               [12]  685 	clr	a
      000144 33               [12]  686 	rlc	a
      000145 24 FF            [12]  687 	add	a,#0xff
      000147 92 A2            [24]  688 	mov	_ZIGZAG_LED,c
                                    689 ;	AT89S52-Buzzer.c:105: RAND_LED    = (currentPattern != 3);
      000149 74 03            [12]  690 	mov	a,#0x03
      00014B B5 22 03         [24]  691 	cjne	a,_currentPattern,00108$
      00014E D3               [12]  692 	setb	c
      00014F 80 01            [24]  693 	sjmp	00109$
      000151                        694 00108$:
      000151 C3               [12]  695 	clr	c
      000152                        696 00109$:
      000152 B3               [12]  697 	cpl	c
      000153 92 08            [24]  698 	mov	b0,c
      000155 E4               [12]  699 	clr	a
      000156 33               [12]  700 	rlc	a
      000157 24 FF            [12]  701 	add	a,#0xff
      000159 92 A3            [24]  702 	mov	_RAND_LED,c
                                    703 ;	AT89S52-Buzzer.c:106: PULSE_LED   = (currentPattern != 4);
      00015B 74 04            [12]  704 	mov	a,#0x04
      00015D B5 22 03         [24]  705 	cjne	a,_currentPattern,00110$
      000160 D3               [12]  706 	setb	c
      000161 80 01            [24]  707 	sjmp	00111$
      000163                        708 00110$:
      000163 C3               [12]  709 	clr	c
      000164                        710 00111$:
      000164 B3               [12]  711 	cpl	c
      000165 92 08            [24]  712 	mov	b0,c
      000167 E4               [12]  713 	clr	a
      000168 33               [12]  714 	rlc	a
      000169 24 FF            [12]  715 	add	a,#0xff
      00016B 92 A4            [24]  716 	mov	_PULSE_LED,c
                                    717 ;	AT89S52-Buzzer.c:107: STEP_LED    = (currentPattern != 5);
      00016D 74 05            [12]  718 	mov	a,#0x05
      00016F B5 22 03         [24]  719 	cjne	a,_currentPattern,00112$
      000172 D3               [12]  720 	setb	c
      000173 80 01            [24]  721 	sjmp	00113$
      000175                        722 00112$:
      000175 C3               [12]  723 	clr	c
      000176                        724 00113$:
      000176 B3               [12]  725 	cpl	c
      000177 92 08            [24]  726 	mov	b0,c
      000179 E4               [12]  727 	clr	a
      00017A 33               [12]  728 	rlc	a
      00017B 24 FF            [12]  729 	add	a,#0xff
      00017D 92 A0            [24]  730 	mov	_STEP_LED,c
                                    731 ;	AT89S52-Buzzer.c:108: TRIANGLE_LED= (currentPattern != 6);
      00017F 74 06            [12]  732 	mov	a,#0x06
      000181 B5 22 03         [24]  733 	cjne	a,_currentPattern,00114$
      000184 D3               [12]  734 	setb	c
      000185 80 01            [24]  735 	sjmp	00115$
      000187                        736 00114$:
      000187 C3               [12]  737 	clr	c
      000188                        738 00115$:
      000188 B3               [12]  739 	cpl	c
      000189 92 08            [24]  740 	mov	b0,c
      00018B E4               [12]  741 	clr	a
      00018C 33               [12]  742 	rlc	a
      00018D 24 FF            [12]  743 	add	a,#0xff
      00018F 92 95            [24]  744 	mov	_TRIANGLE_LED,c
                                    745 ;	AT89S52-Buzzer.c:109: HEART_LED   = (currentPattern != 7);
      000191 74 07            [12]  746 	mov	a,#0x07
      000193 B5 22 03         [24]  747 	cjne	a,_currentPattern,00116$
      000196 D3               [12]  748 	setb	c
      000197 80 01            [24]  749 	sjmp	00117$
      000199                        750 00116$:
      000199 C3               [12]  751 	clr	c
      00019A                        752 00117$:
      00019A B3               [12]  753 	cpl	c
      00019B 92 08            [24]  754 	mov	b0,c
      00019D E4               [12]  755 	clr	a
      00019E 33               [12]  756 	rlc	a
      00019F 24 FF            [12]  757 	add	a,#0xff
      0001A1 92 A1            [24]  758 	mov	_HEART_LED,c
                                    759 ;	AT89S52-Buzzer.c:110: SIREN_LED   = (currentPattern != 8);
      0001A3 74 08            [12]  760 	mov	a,#0x08
      0001A5 B5 22 03         [24]  761 	cjne	a,_currentPattern,00118$
      0001A8 D3               [12]  762 	setb	c
      0001A9 80 01            [24]  763 	sjmp	00119$
      0001AB                        764 00118$:
      0001AB C3               [12]  765 	clr	c
      0001AC                        766 00119$:
      0001AC B3               [12]  767 	cpl	c
      0001AD 92 08            [24]  768 	mov	b0,c
      0001AF E4               [12]  769 	clr	a
      0001B0 33               [12]  770 	rlc	a
      0001B1 24 FF            [12]  771 	add	a,#0xff
      0001B3 92 A2            [24]  772 	mov	_SIREN_LED,c
                                    773 ;	AT89S52-Buzzer.c:111: CHIRP_LED   = (currentPattern != 9);
      0001B5 74 09            [12]  774 	mov	a,#0x09
      0001B7 B5 22 03         [24]  775 	cjne	a,_currentPattern,00120$
      0001BA D3               [12]  776 	setb	c
      0001BB 80 01            [24]  777 	sjmp	00121$
      0001BD                        778 00120$:
      0001BD C3               [12]  779 	clr	c
      0001BE                        780 00121$:
      0001BE B3               [12]  781 	cpl	c
      0001BF 92 08            [24]  782 	mov	b0,c
      0001C1 E4               [12]  783 	clr	a
      0001C2 33               [12]  784 	rlc	a
      0001C3 24 FF            [12]  785 	add	a,#0xff
      0001C5 92 A3            [24]  786 	mov	_CHIRP_LED,c
                                    787 ;	AT89S52-Buzzer.c:112: WALK_LED    = (currentPattern != 10);
      0001C7 74 0A            [12]  788 	mov	a,#0x0a
      0001C9 B5 22 03         [24]  789 	cjne	a,_currentPattern,00122$
      0001CC D3               [12]  790 	setb	c
      0001CD 80 01            [24]  791 	sjmp	00123$
      0001CF                        792 00122$:
      0001CF C3               [12]  793 	clr	c
      0001D0                        794 00123$:
      0001D0 B3               [12]  795 	cpl	c
      0001D1 92 08            [24]  796 	mov	b0,c
      0001D3 E4               [12]  797 	clr	a
      0001D4 33               [12]  798 	rlc	a
      0001D5 24 FF            [12]  799 	add	a,#0xff
      0001D7 92 A4            [24]  800 	mov	_WALK_LED,c
                                    801 ;	AT89S52-Buzzer.c:113: }
      0001D9 22               [24]  802 	ret
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'simple_rand'
                                    805 ;------------------------------------------------------------
                                    806 ;seed                      Allocated with name '_simple_rand_seed_65536_20'
                                    807 ;------------------------------------------------------------
                                    808 ;	AT89S52-Buzzer.c:116: uint8_t simple_rand() {
                                    809 ;	-----------------------------------------
                                    810 ;	 function simple_rand
                                    811 ;	-----------------------------------------
      0001DA                        812 _simple_rand:
                                    813 ;	AT89S52-Buzzer.c:118: seed = (seed * 1103515245 + 12345) % 32768;
      0001DA AC 28            [24]  814 	mov	r4,_simple_rand_seed_65536_20
      0001DC AD 29            [24]  815 	mov	r5,(_simple_rand_seed_65536_20 + 1)
      0001DE 7E 00            [12]  816 	mov	r6,#0x00
      0001E0 7F 00            [12]  817 	mov	r7,#0x00
      0001E2 C0 04            [24]  818 	push	ar4
      0001E4 C0 05            [24]  819 	push	ar5
      0001E6 C0 06            [24]  820 	push	ar6
      0001E8 C0 07            [24]  821 	push	ar7
      0001EA 90 4E 6D         [24]  822 	mov	dptr,#0x4e6d
      0001ED 75 F0 C6         [24]  823 	mov	b,#0xc6
      0001F0 74 41            [12]  824 	mov	a,#0x41
      0001F2 12 08 9E         [24]  825 	lcall	__mullong
      0001F5 AC 82            [24]  826 	mov	r4,dpl
      0001F7 AD 83            [24]  827 	mov	r5,dph
      0001F9 AE F0            [24]  828 	mov	r6,b
      0001FB FF               [12]  829 	mov	r7,a
      0001FC E5 81            [12]  830 	mov	a,sp
      0001FE 24 FC            [12]  831 	add	a,#0xfc
      000200 F5 81            [12]  832 	mov	sp,a
      000202 74 39            [12]  833 	mov	a,#0x39
      000204 2C               [12]  834 	add	a,r4
      000205 FC               [12]  835 	mov	r4,a
      000206 74 30            [12]  836 	mov	a,#0x30
      000208 3D               [12]  837 	addc	a,r5
      000209 FD               [12]  838 	mov	r5,a
      00020A E4               [12]  839 	clr	a
      00020B 3E               [12]  840 	addc	a,r6
      00020C FE               [12]  841 	mov	r6,a
      00020D E4               [12]  842 	clr	a
      00020E 3F               [12]  843 	addc	a,r7
      00020F FF               [12]  844 	mov	r7,a
      000210 E4               [12]  845 	clr	a
      000211 C0 E0            [24]  846 	push	acc
      000213 74 80            [12]  847 	mov	a,#0x80
      000215 C0 E0            [24]  848 	push	acc
      000217 E4               [12]  849 	clr	a
      000218 C0 E0            [24]  850 	push	acc
      00021A C0 E0            [24]  851 	push	acc
      00021C 8C 82            [24]  852 	mov	dpl,r4
      00021E 8D 83            [24]  853 	mov	dph,r5
      000220 8E F0            [24]  854 	mov	b,r6
      000222 EF               [12]  855 	mov	a,r7
      000223 12 07 D8         [24]  856 	lcall	__modslong
      000226 AC 82            [24]  857 	mov	r4,dpl
      000228 AD 83            [24]  858 	mov	r5,dph
      00022A E5 81            [12]  859 	mov	a,sp
      00022C 24 FC            [12]  860 	add	a,#0xfc
      00022E F5 81            [12]  861 	mov	sp,a
      000230 8C 28            [24]  862 	mov	_simple_rand_seed_65536_20,r4
      000232 8D 29            [24]  863 	mov	(_simple_rand_seed_65536_20 + 1),r5
                                    864 ;	AT89S52-Buzzer.c:119: return (uint8_t)(seed & 0xFF);
      000234 85 28 82         [24]  865 	mov	dpl,_simple_rand_seed_65536_20
                                    866 ;	AT89S52-Buzzer.c:120: }
      000237 22               [24]  867 	ret
                                    868 ;------------------------------------------------------------
                                    869 ;Allocation info for local variables in function 'checkButton_PWR'
                                    870 ;------------------------------------------------------------
                                    871 ;current                   Allocated to registers b0 
                                    872 ;------------------------------------------------------------
                                    873 ;	AT89S52-Buzzer.c:123: __bit checkButton_PWR() {
                                    874 ;	-----------------------------------------
                                    875 ;	 function checkButton_PWR
                                    876 ;	-----------------------------------------
      000238                        877 _checkButton_PWR:
                                    878 ;	AT89S52-Buzzer.c:125: __bit current = BTN_POWER;
                                    879 ;	assignBit
      000238 A2 B2            [12]  880 	mov	c,_BTN_POWER
                                    881 ;	AT89S52-Buzzer.c:126: if(current != lastState) {
      00023A 92 08            [24]  882 	mov  b0,c
      00023C 20 03 01         [24]  883 	jb	_checkButton_PWR_lastState_65536_21,00115$
      00023F B3               [12]  884 	cpl	c
      000240                        885 00115$:
      000240 40 1A            [24]  886 	jc	00104$
                                    887 ;	AT89S52-Buzzer.c:127: delay_ms(20);  // Debounce delay
      000242 90 00 14         [24]  888 	mov	dptr,#0x0014
      000245 C0 21            [24]  889 	push	bits
      000247 12 00 B1         [24]  890 	lcall	_delay_ms
      00024A D0 21            [24]  891 	pop	bits
                                    892 ;	AT89S52-Buzzer.c:128: if(BTN_POWER == current) {
      00024C A2 B2            [12]  893 	mov	c,_BTN_POWER
      00024E 20 08 01         [24]  894 	jb	b0,00117$
      000251 B3               [12]  895 	cpl	c
      000252                        896 00117$:
      000252 50 08            [24]  897 	jnc	00104$
                                    898 ;	AT89S52-Buzzer.c:129: lastState = current;
                                    899 ;	assignBit
      000254 A2 08            [12]  900 	mov	c,b0
      000256 92 03            [24]  901 	mov	_checkButton_PWR_lastState_65536_21,c
                                    902 ;	AT89S52-Buzzer.c:130: return !current;  // Active low
      000258 A2 08            [12]  903 	mov	c,b0
      00025A B3               [12]  904 	cpl	c
      00025B 22               [24]  905 	ret
      00025C                        906 00104$:
                                    907 ;	AT89S52-Buzzer.c:133: return 0;
      00025C C3               [12]  908 	clr	c
                                    909 ;	AT89S52-Buzzer.c:134: }
      00025D 22               [24]  910 	ret
                                    911 ;------------------------------------------------------------
                                    912 ;Allocation info for local variables in function 'checkButton_PAT'
                                    913 ;------------------------------------------------------------
                                    914 ;current                   Allocated to registers b0 
                                    915 ;------------------------------------------------------------
                                    916 ;	AT89S52-Buzzer.c:136: __bit checkButton_PAT() {
                                    917 ;	-----------------------------------------
                                    918 ;	 function checkButton_PAT
                                    919 ;	-----------------------------------------
      00025E                        920 _checkButton_PAT:
                                    921 ;	AT89S52-Buzzer.c:138: __bit current = BTN_PATTERN;
                                    922 ;	assignBit
      00025E A2 B3            [12]  923 	mov	c,_BTN_PATTERN
                                    924 ;	AT89S52-Buzzer.c:139: if(current != lastState) {
      000260 92 08            [24]  925 	mov  b0,c
      000262 20 04 01         [24]  926 	jb	_checkButton_PAT_lastState_65536_24,00115$
      000265 B3               [12]  927 	cpl	c
      000266                        928 00115$:
      000266 40 1A            [24]  929 	jc	00104$
                                    930 ;	AT89S52-Buzzer.c:140: delay_ms(20);
      000268 90 00 14         [24]  931 	mov	dptr,#0x0014
      00026B C0 21            [24]  932 	push	bits
      00026D 12 00 B1         [24]  933 	lcall	_delay_ms
      000270 D0 21            [24]  934 	pop	bits
                                    935 ;	AT89S52-Buzzer.c:141: if(BTN_PATTERN == current) {
      000272 A2 B3            [12]  936 	mov	c,_BTN_PATTERN
      000274 20 08 01         [24]  937 	jb	b0,00117$
      000277 B3               [12]  938 	cpl	c
      000278                        939 00117$:
      000278 50 08            [24]  940 	jnc	00104$
                                    941 ;	AT89S52-Buzzer.c:142: lastState = current;
                                    942 ;	assignBit
      00027A A2 08            [12]  943 	mov	c,b0
      00027C 92 04            [24]  944 	mov	_checkButton_PAT_lastState_65536_24,c
                                    945 ;	AT89S52-Buzzer.c:143: return !current;
      00027E A2 08            [12]  946 	mov	c,b0
      000280 B3               [12]  947 	cpl	c
      000281 22               [24]  948 	ret
      000282                        949 00104$:
                                    950 ;	AT89S52-Buzzer.c:146: return 0;
      000282 C3               [12]  951 	clr	c
                                    952 ;	AT89S52-Buzzer.c:147: }
      000283 22               [24]  953 	ret
                                    954 ;------------------------------------------------------------
                                    955 ;Allocation info for local variables in function 'checkButton_SPD'
                                    956 ;------------------------------------------------------------
                                    957 ;current                   Allocated to registers b0 
                                    958 ;------------------------------------------------------------
                                    959 ;	AT89S52-Buzzer.c:149: __bit checkButton_SPD() {
                                    960 ;	-----------------------------------------
                                    961 ;	 function checkButton_SPD
                                    962 ;	-----------------------------------------
      000284                        963 _checkButton_SPD:
                                    964 ;	AT89S52-Buzzer.c:151: __bit current = BTN_SPEED;
                                    965 ;	assignBit
      000284 A2 B4            [12]  966 	mov	c,_BTN_SPEED
                                    967 ;	AT89S52-Buzzer.c:152: if(current != lastState) {
      000286 92 08            [24]  968 	mov  b0,c
      000288 20 05 01         [24]  969 	jb	_checkButton_SPD_lastState_65536_27,00115$
      00028B B3               [12]  970 	cpl	c
      00028C                        971 00115$:
      00028C 40 1A            [24]  972 	jc	00104$
                                    973 ;	AT89S52-Buzzer.c:153: delay_ms(20);
      00028E 90 00 14         [24]  974 	mov	dptr,#0x0014
      000291 C0 21            [24]  975 	push	bits
      000293 12 00 B1         [24]  976 	lcall	_delay_ms
      000296 D0 21            [24]  977 	pop	bits
                                    978 ;	AT89S52-Buzzer.c:154: if(BTN_SPEED == current) {
      000298 A2 B4            [12]  979 	mov	c,_BTN_SPEED
      00029A 20 08 01         [24]  980 	jb	b0,00117$
      00029D B3               [12]  981 	cpl	c
      00029E                        982 00117$:
      00029E 50 08            [24]  983 	jnc	00104$
                                    984 ;	AT89S52-Buzzer.c:155: lastState = current;
                                    985 ;	assignBit
      0002A0 A2 08            [12]  986 	mov	c,b0
      0002A2 92 05            [24]  987 	mov	_checkButton_SPD_lastState_65536_27,c
                                    988 ;	AT89S52-Buzzer.c:156: return !current;
      0002A4 A2 08            [12]  989 	mov	c,b0
      0002A6 B3               [12]  990 	cpl	c
      0002A7 22               [24]  991 	ret
      0002A8                        992 00104$:
                                    993 ;	AT89S52-Buzzer.c:159: return 0;
      0002A8 C3               [12]  994 	clr	c
                                    995 ;	AT89S52-Buzzer.c:160: }
      0002A9 22               [24]  996 	ret
                                    997 ;------------------------------------------------------------
                                    998 ;Allocation info for local variables in function 'checkButton_RNG'
                                    999 ;------------------------------------------------------------
                                   1000 ;current                   Allocated to registers b0 
                                   1001 ;------------------------------------------------------------
                                   1002 ;	AT89S52-Buzzer.c:162: __bit checkButton_RNG() {
                                   1003 ;	-----------------------------------------
                                   1004 ;	 function checkButton_RNG
                                   1005 ;	-----------------------------------------
      0002AA                       1006 _checkButton_RNG:
                                   1007 ;	AT89S52-Buzzer.c:164: __bit current = BTN_RANGE;
                                   1008 ;	assignBit
      0002AA A2 B5            [12] 1009 	mov	c,_BTN_RANGE
                                   1010 ;	AT89S52-Buzzer.c:165: if(current != lastState) {
      0002AC 92 08            [24] 1011 	mov  b0,c
      0002AE 20 06 01         [24] 1012 	jb	_checkButton_RNG_lastState_65536_30,00115$
      0002B1 B3               [12] 1013 	cpl	c
      0002B2                       1014 00115$:
      0002B2 40 1A            [24] 1015 	jc	00104$
                                   1016 ;	AT89S52-Buzzer.c:166: delay_ms(20);
      0002B4 90 00 14         [24] 1017 	mov	dptr,#0x0014
      0002B7 C0 21            [24] 1018 	push	bits
      0002B9 12 00 B1         [24] 1019 	lcall	_delay_ms
      0002BC D0 21            [24] 1020 	pop	bits
                                   1021 ;	AT89S52-Buzzer.c:167: if(BTN_RANGE == current) {
      0002BE A2 B5            [12] 1022 	mov	c,_BTN_RANGE
      0002C0 20 08 01         [24] 1023 	jb	b0,00117$
      0002C3 B3               [12] 1024 	cpl	c
      0002C4                       1025 00117$:
      0002C4 50 08            [24] 1026 	jnc	00104$
                                   1027 ;	AT89S52-Buzzer.c:168: lastState = current;
                                   1028 ;	assignBit
      0002C6 A2 08            [12] 1029 	mov	c,b0
      0002C8 92 06            [24] 1030 	mov	_checkButton_RNG_lastState_65536_30,c
                                   1031 ;	AT89S52-Buzzer.c:169: return !current;
      0002CA A2 08            [12] 1032 	mov	c,b0
      0002CC B3               [12] 1033 	cpl	c
      0002CD 22               [24] 1034 	ret
      0002CE                       1035 00104$:
                                   1036 ;	AT89S52-Buzzer.c:172: return 0;
      0002CE C3               [12] 1037 	clr	c
                                   1038 ;	AT89S52-Buzzer.c:173: }
      0002CF 22               [24] 1039 	ret
                                   1040 ;------------------------------------------------------------
                                   1041 ;Allocation info for local variables in function 'generate_tone'
                                   1042 ;------------------------------------------------------------
                                   1043 ;toneCounter               Allocated with name '_generate_tone_toneCounter_65536_33'
                                   1044 ;------------------------------------------------------------
                                   1045 ;	AT89S52-Buzzer.c:176: void generate_tone() {
                                   1046 ;	-----------------------------------------
                                   1047 ;	 function generate_tone
                                   1048 ;	-----------------------------------------
      0002D0                       1049 _generate_tone:
                                   1050 ;	AT89S52-Buzzer.c:178: if(++toneCounter >= currentFreqDelay) {
      0002D0 05 2A            [12] 1051 	inc	_generate_tone_toneCounter_65536_33
      0002D2 E4               [12] 1052 	clr	a
      0002D3 B5 2A 02         [24] 1053 	cjne	a,_generate_tone_toneCounter_65536_33,00109$
      0002D6 05 2B            [12] 1054 	inc	(_generate_tone_toneCounter_65536_33 + 1)
      0002D8                       1055 00109$:
      0002D8 C3               [12] 1056 	clr	c
      0002D9 E5 2A            [12] 1057 	mov	a,_generate_tone_toneCounter_65536_33
      0002DB 95 24            [12] 1058 	subb	a,_currentFreqDelay
      0002DD E5 2B            [12] 1059 	mov	a,(_generate_tone_toneCounter_65536_33 + 1)
      0002DF 95 25            [12] 1060 	subb	a,(_currentFreqDelay + 1)
      0002E1 40 09            [24] 1061 	jc	00103$
                                   1062 ;	AT89S52-Buzzer.c:179: toneCounter = 0;
      0002E3 E4               [12] 1063 	clr	a
      0002E4 F5 2A            [12] 1064 	mov	_generate_tone_toneCounter_65536_33,a
      0002E6 F5 2B            [12] 1065 	mov	(_generate_tone_toneCounter_65536_33 + 1),a
                                   1066 ;	AT89S52-Buzzer.c:180: BUZZER = !BUZZER;
      0002E8 B2 B0            [12] 1067 	cpl	_BUZZER
                                   1068 ;	AT89S52-Buzzer.c:181: BUZZER_COMP = !BUZZER_COMP;
      0002EA B2 B1            [12] 1069 	cpl	_BUZZER_COMP
      0002EC                       1070 00103$:
                                   1071 ;	AT89S52-Buzzer.c:183: }
      0002EC 22               [24] 1072 	ret
                                   1073 ;------------------------------------------------------------
                                   1074 ;Allocation info for local variables in function 'update_sweep'
                                   1075 ;------------------------------------------------------------
                                   1076 ;minDelay                  Allocated to registers r4 r5 
                                   1077 ;maxDelay                  Allocated to stack - _bp +1
                                   1078 ;sloc0                     Allocated to stack - _bp +5
                                   1079 ;sloc1                     Allocated to stack - _bp +7
                                   1080 ;pulseCount                Allocated with name '_update_sweep_pulseCount_65536_35'
                                   1081 ;stepCount                 Allocated with name '_update_sweep_stepCount_65536_35'
                                   1082 ;freqStep                  Allocated with name '_update_sweep_freqStep_65536_35'
                                   1083 ;hbCount                   Allocated with name '_update_sweep_hbCount_65536_35'
                                   1084 ;sirenCount                Allocated with name '_update_sweep_sirenCount_65536_35'
                                   1085 ;chirpState                Allocated with name '_update_sweep_chirpState_65536_35'
                                   1086 ;chirpCount                Allocated with name '_update_sweep_chirpCount_65536_35'
                                   1087 ;walkCount                 Allocated with name '_update_sweep_walkCount_65536_35'
                                   1088 ;------------------------------------------------------------
                                   1089 ;	AT89S52-Buzzer.c:186: void update_sweep() {
                                   1090 ;	-----------------------------------------
                                   1091 ;	 function update_sweep
                                   1092 ;	-----------------------------------------
      0002ED                       1093 _update_sweep:
      0002ED C0 08            [24] 1094 	push	_bp
      0002EF 85 81 08         [24] 1095 	mov	_bp,sp
      0002F2 05 81            [12] 1096 	inc	sp
      0002F4 05 81            [12] 1097 	inc	sp
                                   1098 ;	AT89S52-Buzzer.c:187: uint16_t minDelay = rangeParams[currentRange][0];
      0002F6 A2 01            [12] 1099 	mov	c,_currentRange
      0002F8 E4               [12] 1100 	clr	a
      0002F9 33               [12] 1101 	rlc	a
      0002FA FE               [12] 1102 	mov	r6,a
      0002FB 7F 00            [12] 1103 	mov	r7,#0x00
      0002FD C0 06            [24] 1104 	push	ar6
      0002FF C0 07            [24] 1105 	push	ar7
      000301 90 00 06         [24] 1106 	mov	dptr,#0x0006
      000304 12 07 B6         [24] 1107 	lcall	__mulint
      000307 AE 82            [24] 1108 	mov	r6,dpl
      000309 AF 83            [24] 1109 	mov	r7,dph
      00030B 15 81            [12] 1110 	dec	sp
      00030D 15 81            [12] 1111 	dec	sp
      00030F EE               [12] 1112 	mov	a,r6
      000310 24 94            [12] 1113 	add	a,#_rangeParams
      000312 FE               [12] 1114 	mov	r6,a
      000313 EF               [12] 1115 	mov	a,r7
      000314 34 09            [12] 1116 	addc	a,#(_rangeParams >> 8)
      000316 FF               [12] 1117 	mov	r7,a
      000317 8E 82            [24] 1118 	mov	dpl,r6
      000319 8F 83            [24] 1119 	mov	dph,r7
      00031B E4               [12] 1120 	clr	a
      00031C 93               [24] 1121 	movc	a,@a+dptr
      00031D FC               [12] 1122 	mov	r4,a
      00031E A3               [24] 1123 	inc	dptr
      00031F E4               [12] 1124 	clr	a
      000320 93               [24] 1125 	movc	a,@a+dptr
      000321 FD               [12] 1126 	mov	r5,a
                                   1127 ;	AT89S52-Buzzer.c:188: uint16_t maxDelay = rangeParams[currentRange][1];
      000322 8E 82            [24] 1128 	mov	dpl,r6
      000324 8F 83            [24] 1129 	mov	dph,r7
      000326 A3               [24] 1130 	inc	dptr
      000327 A3               [24] 1131 	inc	dptr
      000328 A8 08            [24] 1132 	mov	r0,_bp
      00032A 08               [12] 1133 	inc	r0
      00032B E4               [12] 1134 	clr	a
      00032C 93               [24] 1135 	movc	a,@a+dptr
      00032D F6               [12] 1136 	mov	@r0,a
      00032E A3               [24] 1137 	inc	dptr
      00032F E4               [12] 1138 	clr	a
      000330 93               [24] 1139 	movc	a,@a+dptr
      000331 08               [12] 1140 	inc	r0
      000332 F6               [12] 1141 	mov	@r0,a
                                   1142 ;	AT89S52-Buzzer.c:200: switch(currentPattern) {
      000333 E5 22            [12] 1143 	mov	a,_currentPattern
      000335 24 F5            [12] 1144 	add	a,#0xff - 0x0a
      000337 50 03            [24] 1145 	jnc	00256$
      000339 02 07 04         [24] 1146 	ljmp	00164$
      00033C                       1147 00256$:
      00033C E5 22            [12] 1148 	mov	a,_currentPattern
      00033E 24 0B            [12] 1149 	add	a,#(00257$-3-.)
      000340 83               [24] 1150 	movc	a,@a+pc
      000341 F5 82            [12] 1151 	mov	dpl,a
      000343 E5 22            [12] 1152 	mov	a,_currentPattern
      000345 24 0F            [12] 1153 	add	a,#(00258$-3-.)
      000347 83               [24] 1154 	movc	a,@a+pc
      000348 F5 83            [12] 1155 	mov	dph,a
      00034A E4               [12] 1156 	clr	a
      00034B 73               [24] 1157 	jmp	@a+dptr
      00034C                       1158 00257$:
      00034C 62                    1159 	.db	00101$
      00034D 93                    1160 	.db	00105$
      00034E C3                    1161 	.db	00109$
      00034F 1F                    1162 	.db	00119$
      000350 7F                    1163 	.db	00122$
      000351 AF                    1164 	.db	00125$
      000352 22                    1165 	.db	00128$
      000353 79                    1166 	.db	00132$
      000354 EA                    1167 	.db	00144$
      000355 24                    1168 	.db	00147$
      000356 8D                    1169 	.db	00156$
      000357                       1170 00258$:
      000357 03                    1171 	.db	00101$>>8
      000358 03                    1172 	.db	00105$>>8
      000359 03                    1173 	.db	00109$>>8
      00035A 04                    1174 	.db	00119$>>8
      00035B 04                    1175 	.db	00122$>>8
      00035C 04                    1176 	.db	00125$>>8
      00035D 05                    1177 	.db	00128$>>8
      00035E 05                    1178 	.db	00132$>>8
      00035F 05                    1179 	.db	00144$>>8
      000360 06                    1180 	.db	00147$>>8
      000361 06                    1181 	.db	00156$>>8
                                   1182 ;	AT89S52-Buzzer.c:201: case 0: // Up Sweep
      000362                       1183 00101$:
                                   1184 ;	AT89S52-Buzzer.c:202: if(currentFreqDelay > minDelay) 
      000362 C3               [12] 1185 	clr	c
      000363 EC               [12] 1186 	mov	a,r4
      000364 95 24            [12] 1187 	subb	a,_currentFreqDelay
      000366 ED               [12] 1188 	mov	a,r5
      000367 95 25            [12] 1189 	subb	a,(_currentFreqDelay + 1)
      000369 50 1D            [24] 1190 	jnc	00103$
                                   1191 ;	AT89S52-Buzzer.c:203: currentFreqDelay -= speedSteps[currentSpeed];
      00036B E5 23            [12] 1192 	mov	a,_currentSpeed
      00036D 90 09 A0         [24] 1193 	mov	dptr,#_speedSteps
      000370 93               [24] 1194 	movc	a,@a+dptr
      000371 FF               [12] 1195 	mov	r7,a
      000372 7B 00            [12] 1196 	mov	r3,#0x00
      000374 AE 24            [24] 1197 	mov	r6,_currentFreqDelay
      000376 AD 25            [24] 1198 	mov	r5,(_currentFreqDelay + 1)
      000378 8F 02            [24] 1199 	mov	ar2,r7
      00037A EE               [12] 1200 	mov	a,r6
      00037B C3               [12] 1201 	clr	c
      00037C 9A               [12] 1202 	subb	a,r2
      00037D FA               [12] 1203 	mov	r2,a
      00037E ED               [12] 1204 	mov	a,r5
      00037F 9B               [12] 1205 	subb	a,r3
      000380 FB               [12] 1206 	mov	r3,a
      000381 8A 24            [24] 1207 	mov	_currentFreqDelay,r2
      000383 8B 25            [24] 1208 	mov	(_currentFreqDelay + 1),r3
      000385 02 07 04         [24] 1209 	ljmp	00164$
      000388                       1210 00103$:
                                   1211 ;	AT89S52-Buzzer.c:205: currentFreqDelay = maxDelay;
      000388 A8 08            [24] 1212 	mov	r0,_bp
      00038A 08               [12] 1213 	inc	r0
      00038B 86 24            [24] 1214 	mov	_currentFreqDelay,@r0
      00038D 08               [12] 1215 	inc	r0
      00038E 86 25            [24] 1216 	mov	(_currentFreqDelay + 1),@r0
                                   1217 ;	AT89S52-Buzzer.c:206: break;
      000390 02 07 04         [24] 1218 	ljmp	00164$
                                   1219 ;	AT89S52-Buzzer.c:208: case 1: // Down Sweep
      000393                       1220 00105$:
                                   1221 ;	AT89S52-Buzzer.c:209: if(currentFreqDelay < maxDelay) 
      000393 A8 08            [24] 1222 	mov	r0,_bp
      000395 08               [12] 1223 	inc	r0
      000396 C3               [12] 1224 	clr	c
      000397 E5 24            [12] 1225 	mov	a,_currentFreqDelay
      000399 96               [12] 1226 	subb	a,@r0
      00039A E5 25            [12] 1227 	mov	a,(_currentFreqDelay + 1)
      00039C 08               [12] 1228 	inc	r0
      00039D 96               [12] 1229 	subb	a,@r0
      00039E 50 1C            [24] 1230 	jnc	00107$
                                   1231 ;	AT89S52-Buzzer.c:210: currentFreqDelay += speedSteps[currentSpeed];
      0003A0 E5 23            [12] 1232 	mov	a,_currentSpeed
      0003A2 90 09 A0         [24] 1233 	mov	dptr,#_speedSteps
      0003A5 93               [24] 1234 	movc	a,@a+dptr
      0003A6 FF               [12] 1235 	mov	r7,a
      0003A7 7B 00            [12] 1236 	mov	r3,#0x00
      0003A9 AE 24            [24] 1237 	mov	r6,_currentFreqDelay
      0003AB AD 25            [24] 1238 	mov	r5,(_currentFreqDelay + 1)
      0003AD 8F 02            [24] 1239 	mov	ar2,r7
      0003AF EA               [12] 1240 	mov	a,r2
      0003B0 2E               [12] 1241 	add	a,r6
      0003B1 FA               [12] 1242 	mov	r2,a
      0003B2 EB               [12] 1243 	mov	a,r3
      0003B3 3D               [12] 1244 	addc	a,r5
      0003B4 FB               [12] 1245 	mov	r3,a
      0003B5 8A 24            [24] 1246 	mov	_currentFreqDelay,r2
      0003B7 8B 25            [24] 1247 	mov	(_currentFreqDelay + 1),r3
      0003B9 02 07 04         [24] 1248 	ljmp	00164$
      0003BC                       1249 00107$:
                                   1250 ;	AT89S52-Buzzer.c:212: currentFreqDelay = minDelay;
      0003BC 8C 24            [24] 1251 	mov	_currentFreqDelay,r4
      0003BE 8D 25            [24] 1252 	mov	(_currentFreqDelay + 1),r5
                                   1253 ;	AT89S52-Buzzer.c:213: break;
      0003C0 02 07 04         [24] 1254 	ljmp	00164$
                                   1255 ;	AT89S52-Buzzer.c:215: case 2: // Zig-Zag
      0003C3                       1256 00109$:
                                   1257 ;	AT89S52-Buzzer.c:216: if(sweepDirection) {
      0003C3 30 02 2E         [24] 1258 	jnb	_sweepDirection,00117$
                                   1259 ;	AT89S52-Buzzer.c:217: if(currentFreqDelay < maxDelay) 
      0003C6 A8 08            [24] 1260 	mov	r0,_bp
      0003C8 08               [12] 1261 	inc	r0
      0003C9 C3               [12] 1262 	clr	c
      0003CA E5 24            [12] 1263 	mov	a,_currentFreqDelay
      0003CC 96               [12] 1264 	subb	a,@r0
      0003CD E5 25            [12] 1265 	mov	a,(_currentFreqDelay + 1)
      0003CF 08               [12] 1266 	inc	r0
      0003D0 96               [12] 1267 	subb	a,@r0
      0003D1 50 1C            [24] 1268 	jnc	00111$
                                   1269 ;	AT89S52-Buzzer.c:218: currentFreqDelay += speedSteps[currentSpeed];
      0003D3 E5 23            [12] 1270 	mov	a,_currentSpeed
      0003D5 90 09 A0         [24] 1271 	mov	dptr,#_speedSteps
      0003D8 93               [24] 1272 	movc	a,@a+dptr
      0003D9 FF               [12] 1273 	mov	r7,a
      0003DA 7B 00            [12] 1274 	mov	r3,#0x00
      0003DC AE 24            [24] 1275 	mov	r6,_currentFreqDelay
      0003DE AD 25            [24] 1276 	mov	r5,(_currentFreqDelay + 1)
      0003E0 8F 02            [24] 1277 	mov	ar2,r7
      0003E2 EA               [12] 1278 	mov	a,r2
      0003E3 2E               [12] 1279 	add	a,r6
      0003E4 FA               [12] 1280 	mov	r2,a
      0003E5 EB               [12] 1281 	mov	a,r3
      0003E6 3D               [12] 1282 	addc	a,r5
      0003E7 FB               [12] 1283 	mov	r3,a
      0003E8 8A 24            [24] 1284 	mov	_currentFreqDelay,r2
      0003EA 8B 25            [24] 1285 	mov	(_currentFreqDelay + 1),r3
      0003EC 02 07 04         [24] 1286 	ljmp	00164$
      0003EF                       1287 00111$:
                                   1288 ;	AT89S52-Buzzer.c:220: sweepDirection = 0;
                                   1289 ;	assignBit
      0003EF C2 02            [12] 1290 	clr	_sweepDirection
      0003F1 02 07 04         [24] 1291 	ljmp	00164$
      0003F4                       1292 00117$:
                                   1293 ;	AT89S52-Buzzer.c:222: if(currentFreqDelay > minDelay) 
      0003F4 C3               [12] 1294 	clr	c
      0003F5 EC               [12] 1295 	mov	a,r4
      0003F6 95 24            [12] 1296 	subb	a,_currentFreqDelay
      0003F8 ED               [12] 1297 	mov	a,r5
      0003F9 95 25            [12] 1298 	subb	a,(_currentFreqDelay + 1)
      0003FB 50 1D            [24] 1299 	jnc	00114$
                                   1300 ;	AT89S52-Buzzer.c:223: currentFreqDelay -= speedSteps[currentSpeed];
      0003FD E5 23            [12] 1301 	mov	a,_currentSpeed
      0003FF 90 09 A0         [24] 1302 	mov	dptr,#_speedSteps
      000402 93               [24] 1303 	movc	a,@a+dptr
      000403 FF               [12] 1304 	mov	r7,a
      000404 7B 00            [12] 1305 	mov	r3,#0x00
      000406 AE 24            [24] 1306 	mov	r6,_currentFreqDelay
      000408 AD 25            [24] 1307 	mov	r5,(_currentFreqDelay + 1)
      00040A 8F 02            [24] 1308 	mov	ar2,r7
      00040C EE               [12] 1309 	mov	a,r6
      00040D C3               [12] 1310 	clr	c
      00040E 9A               [12] 1311 	subb	a,r2
      00040F FA               [12] 1312 	mov	r2,a
      000410 ED               [12] 1313 	mov	a,r5
      000411 9B               [12] 1314 	subb	a,r3
      000412 FB               [12] 1315 	mov	r3,a
      000413 8A 24            [24] 1316 	mov	_currentFreqDelay,r2
      000415 8B 25            [24] 1317 	mov	(_currentFreqDelay + 1),r3
      000417 02 07 04         [24] 1318 	ljmp	00164$
      00041A                       1319 00114$:
                                   1320 ;	AT89S52-Buzzer.c:225: sweepDirection = 1;
                                   1321 ;	assignBit
      00041A D2 02            [12] 1322 	setb	_sweepDirection
                                   1323 ;	AT89S52-Buzzer.c:227: break;
      00041C 02 07 04         [24] 1324 	ljmp	00164$
                                   1325 ;	AT89S52-Buzzer.c:229: case 3: // Random
      00041F                       1326 00119$:
                                   1327 ;	AT89S52-Buzzer.c:230: if(simple_rand() < 20) // ~8% chance to change
      00041F C0 05            [24] 1328 	push	ar5
      000421 C0 04            [24] 1329 	push	ar4
      000423 12 01 DA         [24] 1330 	lcall	_simple_rand
      000426 AB 82            [24] 1331 	mov	r3,dpl
      000428 D0 04            [24] 1332 	pop	ar4
      00042A D0 05            [24] 1333 	pop	ar5
      00042C BB 14 00         [24] 1334 	cjne	r3,#0x14,00264$
      00042F                       1335 00264$:
      00042F 40 03            [24] 1336 	jc	00265$
      000431 02 07 04         [24] 1337 	ljmp	00164$
      000434                       1338 00265$:
                                   1339 ;	AT89S52-Buzzer.c:231: currentFreqDelay = minDelay + (simple_rand() % (maxDelay-minDelay+1));
      000434 C0 05            [24] 1340 	push	ar5
      000436 C0 04            [24] 1341 	push	ar4
      000438 12 01 DA         [24] 1342 	lcall	_simple_rand
      00043B AB 82            [24] 1343 	mov	r3,dpl
      00043D D0 04            [24] 1344 	pop	ar4
      00043F D0 05            [24] 1345 	pop	ar5
      000441 A8 08            [24] 1346 	mov	r0,_bp
      000443 08               [12] 1347 	inc	r0
      000444 E6               [12] 1348 	mov	a,@r0
      000445 C3               [12] 1349 	clr	c
      000446 9C               [12] 1350 	subb	a,r4
      000447 FA               [12] 1351 	mov	r2,a
      000448 08               [12] 1352 	inc	r0
      000449 E6               [12] 1353 	mov	a,@r0
      00044A 9D               [12] 1354 	subb	a,r5
      00044B FF               [12] 1355 	mov	r7,a
      00044C 0A               [12] 1356 	inc	r2
      00044D BA 00 01         [24] 1357 	cjne	r2,#0x00,00266$
      000450 0F               [12] 1358 	inc	r7
      000451                       1359 00266$:
      000451 7E 00            [12] 1360 	mov	r6,#0x00
      000453 C0 05            [24] 1361 	push	ar5
      000455 C0 04            [24] 1362 	push	ar4
      000457 C0 02            [24] 1363 	push	ar2
      000459 C0 07            [24] 1364 	push	ar7
      00045B 8B 82            [24] 1365 	mov	dpl,r3
      00045D 8E 83            [24] 1366 	mov	dph,r6
      00045F 12 09 4B         [24] 1367 	lcall	__moduint
      000462 AE 82            [24] 1368 	mov	r6,dpl
      000464 AF 83            [24] 1369 	mov	r7,dph
      000466 15 81            [12] 1370 	dec	sp
      000468 15 81            [12] 1371 	dec	sp
      00046A D0 04            [24] 1372 	pop	ar4
      00046C D0 05            [24] 1373 	pop	ar5
      00046E 8C 02            [24] 1374 	mov	ar2,r4
      000470 8D 03            [24] 1375 	mov	ar3,r5
      000472 EE               [12] 1376 	mov	a,r6
      000473 2A               [12] 1377 	add	a,r2
      000474 FE               [12] 1378 	mov	r6,a
      000475 EF               [12] 1379 	mov	a,r7
      000476 3B               [12] 1380 	addc	a,r3
      000477 FF               [12] 1381 	mov	r7,a
      000478 8E 24            [24] 1382 	mov	_currentFreqDelay,r6
      00047A 8F 25            [24] 1383 	mov	(_currentFreqDelay + 1),r7
                                   1384 ;	AT89S52-Buzzer.c:232: break;
      00047C 02 07 04         [24] 1385 	ljmp	00164$
                                   1386 ;	AT89S52-Buzzer.c:234: case 4: // Pulse
      00047F                       1387 00122$:
                                   1388 ;	AT89S52-Buzzer.c:235: if(++pulseCount >= 500) pulseCount = 0;
      00047F 05 2C            [12] 1389 	inc	_update_sweep_pulseCount_65536_35
      000481 E4               [12] 1390 	clr	a
      000482 B5 2C 02         [24] 1391 	cjne	a,_update_sweep_pulseCount_65536_35,00267$
      000485 05 2D            [12] 1392 	inc	(_update_sweep_pulseCount_65536_35 + 1)
      000487                       1393 00267$:
      000487 AE 2C            [24] 1394 	mov	r6,_update_sweep_pulseCount_65536_35
      000489 AF 2D            [24] 1395 	mov	r7,(_update_sweep_pulseCount_65536_35 + 1)
      00048B C3               [12] 1396 	clr	c
      00048C EE               [12] 1397 	mov	a,r6
      00048D 94 F4            [12] 1398 	subb	a,#0xf4
      00048F EF               [12] 1399 	mov	a,r7
      000490 94 01            [12] 1400 	subb	a,#0x01
      000492 40 05            [24] 1401 	jc	00124$
      000494 E4               [12] 1402 	clr	a
      000495 F5 2C            [12] 1403 	mov	_update_sweep_pulseCount_65536_35,a
      000497 F5 2D            [12] 1404 	mov	(_update_sweep_pulseCount_65536_35 + 1),a
      000499                       1405 00124$:
                                   1406 ;	AT89S52-Buzzer.c:236: BUZZER = (pulseCount < 50); // 10% duty cycle
      000499 AE 2C            [24] 1407 	mov	r6,_update_sweep_pulseCount_65536_35
      00049B AF 2D            [24] 1408 	mov	r7,(_update_sweep_pulseCount_65536_35 + 1)
      00049D C3               [12] 1409 	clr	c
      00049E EE               [12] 1410 	mov	a,r6
      00049F 94 32            [12] 1411 	subb	a,#0x32
      0004A1 EF               [12] 1412 	mov	a,r7
      0004A2 94 00            [12] 1413 	subb	a,#0x00
      0004A4 92 08            [24] 1414 	mov  b0,c
      0004A6 E4               [12] 1415 	clr	a
      0004A7 33               [12] 1416 	rlc	a
      0004A8 24 FF            [12] 1417 	add	a,#0xff
      0004AA 92 B0            [24] 1418 	mov	_BUZZER,c
                                   1419 ;	AT89S52-Buzzer.c:237: break;
      0004AC 02 07 04         [24] 1420 	ljmp	00164$
                                   1421 ;	AT89S52-Buzzer.c:239: case 5: // Stepped
      0004AF                       1422 00125$:
                                   1423 ;	AT89S52-Buzzer.c:240: if(++stepCount >= 100) {
      0004AF 05 2E            [12] 1424 	inc	_update_sweep_stepCount_65536_35
      0004B1 E4               [12] 1425 	clr	a
      0004B2 B5 2E 02         [24] 1426 	cjne	a,_update_sweep_stepCount_65536_35,00269$
      0004B5 05 2F            [12] 1427 	inc	(_update_sweep_stepCount_65536_35 + 1)
      0004B7                       1428 00269$:
      0004B7 AE 2E            [24] 1429 	mov	r6,_update_sweep_stepCount_65536_35
      0004B9 AF 2F            [24] 1430 	mov	r7,(_update_sweep_stepCount_65536_35 + 1)
      0004BB C3               [12] 1431 	clr	c
      0004BC EE               [12] 1432 	mov	a,r6
      0004BD 94 64            [12] 1433 	subb	a,#0x64
      0004BF EF               [12] 1434 	mov	a,r7
      0004C0 94 00            [12] 1435 	subb	a,#0x00
      0004C2 50 03            [24] 1436 	jnc	00270$
      0004C4 02 07 04         [24] 1437 	ljmp	00164$
      0004C7                       1438 00270$:
                                   1439 ;	AT89S52-Buzzer.c:241: stepCount = 0;
      0004C7 E4               [12] 1440 	clr	a
      0004C8 F5 2E            [12] 1441 	mov	_update_sweep_stepCount_65536_35,a
      0004CA F5 2F            [12] 1442 	mov	(_update_sweep_stepCount_65536_35 + 1),a
                                   1443 ;	AT89S52-Buzzer.c:243: ((currentFreqDelay + speedSteps[currentSpeed] - minDelay) % 
      0004CC E5 23            [12] 1444 	mov	a,_currentSpeed
      0004CE 90 09 A0         [24] 1445 	mov	dptr,#_speedSteps
      0004D1 93               [24] 1446 	movc	a,@a+dptr
      0004D2 FF               [12] 1447 	mov	r7,a
      0004D3 7E 00            [12] 1448 	mov	r6,#0x00
      0004D5 AA 24            [24] 1449 	mov	r2,_currentFreqDelay
      0004D7 AB 25            [24] 1450 	mov	r3,(_currentFreqDelay + 1)
      0004D9 EF               [12] 1451 	mov	a,r7
      0004DA 2A               [12] 1452 	add	a,r2
      0004DB FA               [12] 1453 	mov	r2,a
      0004DC EE               [12] 1454 	mov	a,r6
      0004DD 3B               [12] 1455 	addc	a,r3
      0004DE FB               [12] 1456 	mov	r3,a
      0004DF EA               [12] 1457 	mov	a,r2
      0004E0 C3               [12] 1458 	clr	c
      0004E1 9C               [12] 1459 	subb	a,r4
      0004E2 FA               [12] 1460 	mov	r2,a
      0004E3 EB               [12] 1461 	mov	a,r3
      0004E4 9D               [12] 1462 	subb	a,r5
      0004E5 FB               [12] 1463 	mov	r3,a
                                   1464 ;	AT89S52-Buzzer.c:244: (maxDelay-minDelay+1));
      0004E6 A8 08            [24] 1465 	mov	r0,_bp
      0004E8 08               [12] 1466 	inc	r0
      0004E9 E6               [12] 1467 	mov	a,@r0
      0004EA C3               [12] 1468 	clr	c
      0004EB 9C               [12] 1469 	subb	a,r4
      0004EC FE               [12] 1470 	mov	r6,a
      0004ED 08               [12] 1471 	inc	r0
      0004EE E6               [12] 1472 	mov	a,@r0
      0004EF 9D               [12] 1473 	subb	a,r5
      0004F0 FF               [12] 1474 	mov	r7,a
      0004F1 0E               [12] 1475 	inc	r6
      0004F2 BE 00 01         [24] 1476 	cjne	r6,#0x00,00271$
      0004F5 0F               [12] 1477 	inc	r7
      0004F6                       1478 00271$:
      0004F6 8A 82            [24] 1479 	mov	dpl,r2
      0004F8 8B 83            [24] 1480 	mov	dph,r3
      0004FA C0 05            [24] 1481 	push	ar5
      0004FC C0 04            [24] 1482 	push	ar4
      0004FE C0 06            [24] 1483 	push	ar6
      000500 C0 07            [24] 1484 	push	ar7
      000502 12 09 4B         [24] 1485 	lcall	__moduint
      000505 AE 82            [24] 1486 	mov	r6,dpl
      000507 AF 83            [24] 1487 	mov	r7,dph
      000509 15 81            [12] 1488 	dec	sp
      00050B 15 81            [12] 1489 	dec	sp
      00050D D0 04            [24] 1490 	pop	ar4
      00050F D0 05            [24] 1491 	pop	ar5
      000511 8C 02            [24] 1492 	mov	ar2,r4
      000513 8D 03            [24] 1493 	mov	ar3,r5
      000515 EE               [12] 1494 	mov	a,r6
      000516 2A               [12] 1495 	add	a,r2
      000517 FE               [12] 1496 	mov	r6,a
      000518 EF               [12] 1497 	mov	a,r7
      000519 3B               [12] 1498 	addc	a,r3
      00051A FF               [12] 1499 	mov	r7,a
      00051B 8E 24            [24] 1500 	mov	_currentFreqDelay,r6
      00051D 8F 25            [24] 1501 	mov	(_currentFreqDelay + 1),r7
                                   1502 ;	AT89S52-Buzzer.c:246: break;
      00051F 02 07 04         [24] 1503 	ljmp	00164$
                                   1504 ;	AT89S52-Buzzer.c:248: case 6: // Triangle
      000522                       1505 00128$:
                                   1506 ;	AT89S52-Buzzer.c:249: currentFreqDelay += freqStep * speedSteps[currentSpeed];
      000522 E5 23            [12] 1507 	mov	a,_currentSpeed
      000524 90 09 A0         [24] 1508 	mov	dptr,#_speedSteps
      000527 93               [24] 1509 	movc	a,@a+dptr
      000528 FF               [12] 1510 	mov	r7,a
      000529 7E 00            [12] 1511 	mov	r6,#0x00
      00052B C0 05            [24] 1512 	push	ar5
      00052D C0 04            [24] 1513 	push	ar4
      00052F C0 07            [24] 1514 	push	ar7
      000531 C0 06            [24] 1515 	push	ar6
      000533 85 30 82         [24] 1516 	mov	dpl,_update_sweep_freqStep_65536_35
      000536 85 31 83         [24] 1517 	mov	dph,(_update_sweep_freqStep_65536_35 + 1)
      000539 12 07 B6         [24] 1518 	lcall	__mulint
      00053C AE 82            [24] 1519 	mov	r6,dpl
      00053E AF 83            [24] 1520 	mov	r7,dph
      000540 15 81            [12] 1521 	dec	sp
      000542 15 81            [12] 1522 	dec	sp
      000544 D0 04            [24] 1523 	pop	ar4
      000546 D0 05            [24] 1524 	pop	ar5
      000548 EE               [12] 1525 	mov	a,r6
      000549 25 24            [12] 1526 	add	a,_currentFreqDelay
      00054B F5 24            [12] 1527 	mov	_currentFreqDelay,a
      00054D EF               [12] 1528 	mov	a,r7
      00054E 35 25            [12] 1529 	addc	a,(_currentFreqDelay + 1)
      000550 F5 25            [12] 1530 	mov	(_currentFreqDelay + 1),a
                                   1531 ;	AT89S52-Buzzer.c:250: if(currentFreqDelay <= minDelay || currentFreqDelay >= maxDelay)
      000552 C3               [12] 1532 	clr	c
      000553 EC               [12] 1533 	mov	a,r4
      000554 95 24            [12] 1534 	subb	a,_currentFreqDelay
      000556 ED               [12] 1535 	mov	a,r5
      000557 95 25            [12] 1536 	subb	a,(_currentFreqDelay + 1)
      000559 50 10            [24] 1537 	jnc	00129$
      00055B A8 08            [24] 1538 	mov	r0,_bp
      00055D 08               [12] 1539 	inc	r0
      00055E C3               [12] 1540 	clr	c
      00055F E5 24            [12] 1541 	mov	a,_currentFreqDelay
      000561 96               [12] 1542 	subb	a,@r0
      000562 E5 25            [12] 1543 	mov	a,(_currentFreqDelay + 1)
      000564 08               [12] 1544 	inc	r0
      000565 96               [12] 1545 	subb	a,@r0
      000566 50 03            [24] 1546 	jnc	00273$
      000568 02 07 04         [24] 1547 	ljmp	00164$
      00056B                       1548 00273$:
      00056B                       1549 00129$:
                                   1550 ;	AT89S52-Buzzer.c:251: freqStep = -freqStep;
      00056B C3               [12] 1551 	clr	c
      00056C E4               [12] 1552 	clr	a
      00056D 95 30            [12] 1553 	subb	a,_update_sweep_freqStep_65536_35
      00056F F5 30            [12] 1554 	mov	_update_sweep_freqStep_65536_35,a
      000571 E4               [12] 1555 	clr	a
      000572 95 31            [12] 1556 	subb	a,(_update_sweep_freqStep_65536_35 + 1)
      000574 F5 31            [12] 1557 	mov	(_update_sweep_freqStep_65536_35 + 1),a
                                   1558 ;	AT89S52-Buzzer.c:252: break;
      000576 02 07 04         [24] 1559 	ljmp	00164$
                                   1560 ;	AT89S52-Buzzer.c:254: case 7: // Heartbeat
      000579                       1561 00132$:
                                   1562 ;	AT89S52-Buzzer.c:255: if(++hbCount >= 600) hbCount = 0;
      000579 05 32            [12] 1563 	inc	_update_sweep_hbCount_65536_35
      00057B E4               [12] 1564 	clr	a
      00057C B5 32 02         [24] 1565 	cjne	a,_update_sweep_hbCount_65536_35,00274$
      00057F 05 33            [12] 1566 	inc	(_update_sweep_hbCount_65536_35 + 1)
      000581                       1567 00274$:
      000581 AE 32            [24] 1568 	mov	r6,_update_sweep_hbCount_65536_35
      000583 AF 33            [24] 1569 	mov	r7,(_update_sweep_hbCount_65536_35 + 1)
      000585 C3               [12] 1570 	clr	c
      000586 EE               [12] 1571 	mov	a,r6
      000587 94 58            [12] 1572 	subb	a,#0x58
      000589 EF               [12] 1573 	mov	a,r7
      00058A 94 02            [12] 1574 	subb	a,#0x02
      00058C 40 05            [24] 1575 	jc	00134$
      00058E E4               [12] 1576 	clr	a
      00058F F5 32            [12] 1577 	mov	_update_sweep_hbCount_65536_35,a
      000591 F5 33            [12] 1578 	mov	(_update_sweep_hbCount_65536_35 + 1),a
      000593                       1579 00134$:
                                   1580 ;	AT89S52-Buzzer.c:257: if(hbCount < 100)       // First beat
      000593 AE 32            [24] 1581 	mov	r6,_update_sweep_hbCount_65536_35
      000595 AF 33            [24] 1582 	mov	r7,(_update_sweep_hbCount_65536_35 + 1)
      000597 C3               [12] 1583 	clr	c
      000598 EE               [12] 1584 	mov	a,r6
      000599 94 64            [12] 1585 	subb	a,#0x64
      00059B EF               [12] 1586 	mov	a,r7
      00059C 94 00            [12] 1587 	subb	a,#0x00
      00059E 50 12            [24] 1588 	jnc	00142$
                                   1589 ;	AT89S52-Buzzer.c:258: currentFreqDelay = minDelay + 2;
      0005A0 8C 02            [24] 1590 	mov	ar2,r4
      0005A2 8D 03            [24] 1591 	mov	ar3,r5
      0005A4 74 02            [12] 1592 	mov	a,#0x02
      0005A6 2A               [12] 1593 	add	a,r2
      0005A7 FA               [12] 1594 	mov	r2,a
      0005A8 E4               [12] 1595 	clr	a
      0005A9 3B               [12] 1596 	addc	a,r3
      0005AA FB               [12] 1597 	mov	r3,a
      0005AB 8A 24            [24] 1598 	mov	_currentFreqDelay,r2
      0005AD 8B 25            [24] 1599 	mov	(_currentFreqDelay + 1),r3
      0005AF 02 07 04         [24] 1600 	ljmp	00164$
      0005B2                       1601 00142$:
                                   1602 ;	AT89S52-Buzzer.c:259: else if(hbCount < 150)  // First pause
      0005B2 C3               [12] 1603 	clr	c
      0005B3 EE               [12] 1604 	mov	a,r6
      0005B4 94 96            [12] 1605 	subb	a,#0x96
      0005B6 EF               [12] 1606 	mov	a,r7
      0005B7 94 00            [12] 1607 	subb	a,#0x00
      0005B9 50 0B            [24] 1608 	jnc	00139$
                                   1609 ;	AT89S52-Buzzer.c:260: currentFreqDelay = maxDelay;
      0005BB A8 08            [24] 1610 	mov	r0,_bp
      0005BD 08               [12] 1611 	inc	r0
      0005BE 86 24            [24] 1612 	mov	_currentFreqDelay,@r0
      0005C0 08               [12] 1613 	inc	r0
      0005C1 86 25            [24] 1614 	mov	(_currentFreqDelay + 1),@r0
      0005C3 02 07 04         [24] 1615 	ljmp	00164$
      0005C6                       1616 00139$:
                                   1617 ;	AT89S52-Buzzer.c:261: else if(hbCount < 250)  // Second beat
      0005C6 C3               [12] 1618 	clr	c
      0005C7 EE               [12] 1619 	mov	a,r6
      0005C8 94 FA            [12] 1620 	subb	a,#0xfa
      0005CA EF               [12] 1621 	mov	a,r7
      0005CB 94 00            [12] 1622 	subb	a,#0x00
      0005CD 50 10            [24] 1623 	jnc	00136$
                                   1624 ;	AT89S52-Buzzer.c:262: currentFreqDelay = minDelay + 1;
      0005CF 8C 06            [24] 1625 	mov	ar6,r4
      0005D1 8D 07            [24] 1626 	mov	ar7,r5
      0005D3 0E               [12] 1627 	inc	r6
      0005D4 BE 00 01         [24] 1628 	cjne	r6,#0x00,00279$
      0005D7 0F               [12] 1629 	inc	r7
      0005D8                       1630 00279$:
      0005D8 8E 24            [24] 1631 	mov	_currentFreqDelay,r6
      0005DA 8F 25            [24] 1632 	mov	(_currentFreqDelay + 1),r7
      0005DC 02 07 04         [24] 1633 	ljmp	00164$
      0005DF                       1634 00136$:
                                   1635 ;	AT89S52-Buzzer.c:264: currentFreqDelay = maxDelay;
      0005DF A8 08            [24] 1636 	mov	r0,_bp
      0005E1 08               [12] 1637 	inc	r0
      0005E2 86 24            [24] 1638 	mov	_currentFreqDelay,@r0
      0005E4 08               [12] 1639 	inc	r0
      0005E5 86 25            [24] 1640 	mov	(_currentFreqDelay + 1),@r0
                                   1641 ;	AT89S52-Buzzer.c:265: break;
      0005E7 02 07 04         [24] 1642 	ljmp	00164$
                                   1643 ;	AT89S52-Buzzer.c:267: case 8: // Siren
      0005EA                       1644 00144$:
                                   1645 ;	AT89S52-Buzzer.c:268: if(++sirenCount >= 100) {
      0005EA 05 34            [12] 1646 	inc	_update_sweep_sirenCount_65536_35
      0005EC E4               [12] 1647 	clr	a
      0005ED B5 34 02         [24] 1648 	cjne	a,_update_sweep_sirenCount_65536_35,00280$
      0005F0 05 35            [12] 1649 	inc	(_update_sweep_sirenCount_65536_35 + 1)
      0005F2                       1650 00280$:
      0005F2 AE 34            [24] 1651 	mov	r6,_update_sweep_sirenCount_65536_35
      0005F4 AF 35            [24] 1652 	mov	r7,(_update_sweep_sirenCount_65536_35 + 1)
      0005F6 C3               [12] 1653 	clr	c
      0005F7 EE               [12] 1654 	mov	a,r6
      0005F8 94 64            [12] 1655 	subb	a,#0x64
      0005FA EF               [12] 1656 	mov	a,r7
      0005FB 94 00            [12] 1657 	subb	a,#0x00
      0005FD 50 03            [24] 1658 	jnc	00281$
      0005FF 02 07 04         [24] 1659 	ljmp	00164$
      000602                       1660 00281$:
                                   1661 ;	AT89S52-Buzzer.c:269: sirenCount = 0;
      000602 E4               [12] 1662 	clr	a
      000603 F5 34            [12] 1663 	mov	_update_sweep_sirenCount_65536_35,a
      000605 F5 35            [12] 1664 	mov	(_update_sweep_sirenCount_65536_35 + 1),a
                                   1665 ;	AT89S52-Buzzer.c:270: currentFreqDelay = (currentFreqDelay == minDelay) ? maxDelay : minDelay;
      000607 EC               [12] 1666 	mov	a,r4
      000608 B5 24 0E         [24] 1667 	cjne	a,_currentFreqDelay,00166$
      00060B ED               [12] 1668 	mov	a,r5
      00060C B5 25 0A         [24] 1669 	cjne	a,(_currentFreqDelay + 1),00166$
      00060F A8 08            [24] 1670 	mov	r0,_bp
      000611 08               [12] 1671 	inc	r0
      000612 86 06            [24] 1672 	mov	ar6,@r0
      000614 08               [12] 1673 	inc	r0
      000615 86 07            [24] 1674 	mov	ar7,@r0
      000617 80 04            [24] 1675 	sjmp	00167$
      000619                       1676 00166$:
      000619 8C 06            [24] 1677 	mov	ar6,r4
      00061B 8D 07            [24] 1678 	mov	ar7,r5
      00061D                       1679 00167$:
      00061D 8E 24            [24] 1680 	mov	_currentFreqDelay,r6
      00061F 8F 25            [24] 1681 	mov	(_currentFreqDelay + 1),r7
                                   1682 ;	AT89S52-Buzzer.c:272: break;
      000621 02 07 04         [24] 1683 	ljmp	00164$
                                   1684 ;	AT89S52-Buzzer.c:274: case 9: // Chirps
      000624                       1685 00147$:
                                   1686 ;	AT89S52-Buzzer.c:275: if(chirpState == 0) {
      000624 E5 36            [12] 1687 	mov	a,_update_sweep_chirpState_65536_35
      000626 70 3C            [24] 1688 	jnz	00154$
                                   1689 ;	AT89S52-Buzzer.c:276: if(currentFreqDelay > minDelay)
      000628 C3               [12] 1690 	clr	c
      000629 EC               [12] 1691 	mov	a,r4
      00062A 95 24            [12] 1692 	subb	a,_currentFreqDelay
      00062C ED               [12] 1693 	mov	a,r5
      00062D 95 25            [12] 1694 	subb	a,(_currentFreqDelay + 1)
      00062F 50 2D            [24] 1695 	jnc	00149$
                                   1696 ;	AT89S52-Buzzer.c:277: currentFreqDelay -= speedSteps[currentSpeed]*3;
      000631 E5 23            [12] 1697 	mov	a,_currentSpeed
      000633 90 09 A0         [24] 1698 	mov	dptr,#_speedSteps
      000636 93               [24] 1699 	movc	a,@a+dptr
      000637 FF               [12] 1700 	mov	r7,a
      000638 7E 00            [12] 1701 	mov	r6,#0x00
      00063A C0 07            [24] 1702 	push	ar7
      00063C C0 06            [24] 1703 	push	ar6
      00063E 90 00 03         [24] 1704 	mov	dptr,#0x0003
      000641 12 07 B6         [24] 1705 	lcall	__mulint
      000644 AE 82            [24] 1706 	mov	r6,dpl
      000646 AF 83            [24] 1707 	mov	r7,dph
      000648 15 81            [12] 1708 	dec	sp
      00064A 15 81            [12] 1709 	dec	sp
      00064C AA 24            [24] 1710 	mov	r2,_currentFreqDelay
      00064E AB 25            [24] 1711 	mov	r3,(_currentFreqDelay + 1)
      000650 EA               [12] 1712 	mov	a,r2
      000651 C3               [12] 1713 	clr	c
      000652 9E               [12] 1714 	subb	a,r6
      000653 FA               [12] 1715 	mov	r2,a
      000654 EB               [12] 1716 	mov	a,r3
      000655 9F               [12] 1717 	subb	a,r7
      000656 FB               [12] 1718 	mov	r3,a
      000657 8A 24            [24] 1719 	mov	_currentFreqDelay,r2
      000659 8B 25            [24] 1720 	mov	(_currentFreqDelay + 1),r3
      00065B 02 07 04         [24] 1721 	ljmp	00164$
      00065E                       1722 00149$:
                                   1723 ;	AT89S52-Buzzer.c:279: chirpState = 1;
      00065E 75 36 01         [24] 1724 	mov	_update_sweep_chirpState_65536_35,#0x01
      000661 02 07 04         [24] 1725 	ljmp	00164$
      000664                       1726 00154$:
                                   1727 ;	AT89S52-Buzzer.c:280: } else if(++chirpCount > 300) {
      000664 05 37            [12] 1728 	inc	_update_sweep_chirpCount_65536_35
      000666 E4               [12] 1729 	clr	a
      000667 B5 37 02         [24] 1730 	cjne	a,_update_sweep_chirpCount_65536_35,00286$
      00066A 05 38            [12] 1731 	inc	(_update_sweep_chirpCount_65536_35 + 1)
      00066C                       1732 00286$:
      00066C AE 37            [24] 1733 	mov	r6,_update_sweep_chirpCount_65536_35
      00066E AF 38            [24] 1734 	mov	r7,(_update_sweep_chirpCount_65536_35 + 1)
      000670 C3               [12] 1735 	clr	c
      000671 74 2C            [12] 1736 	mov	a,#0x2c
      000673 9E               [12] 1737 	subb	a,r6
      000674 74 01            [12] 1738 	mov	a,#0x01
      000676 9F               [12] 1739 	subb	a,r7
      000677 40 03            [24] 1740 	jc	00287$
      000679 02 07 04         [24] 1741 	ljmp	00164$
      00067C                       1742 00287$:
                                   1743 ;	AT89S52-Buzzer.c:281: chirpCount = 0;
      00067C E4               [12] 1744 	clr	a
      00067D F5 37            [12] 1745 	mov	_update_sweep_chirpCount_65536_35,a
      00067F F5 38            [12] 1746 	mov	(_update_sweep_chirpCount_65536_35 + 1),a
                                   1747 ;	AT89S52-Buzzer.c:282: chirpState = 0;
                                   1748 ;	1-genFromRTrack replaced	mov	_update_sweep_chirpState_65536_35,#0x00
      000681 F5 36            [12] 1749 	mov	_update_sweep_chirpState_65536_35,a
                                   1750 ;	AT89S52-Buzzer.c:283: currentFreqDelay = maxDelay;
      000683 A8 08            [24] 1751 	mov	r0,_bp
      000685 08               [12] 1752 	inc	r0
      000686 86 24            [24] 1753 	mov	_currentFreqDelay,@r0
      000688 08               [12] 1754 	inc	r0
      000689 86 25            [24] 1755 	mov	(_currentFreqDelay + 1),@r0
                                   1756 ;	AT89S52-Buzzer.c:285: break;
                                   1757 ;	AT89S52-Buzzer.c:287: case 10: // Random Walk
      00068B 80 77            [24] 1758 	sjmp	00164$
      00068D                       1759 00156$:
                                   1760 ;	AT89S52-Buzzer.c:288: if(++walkCount >= 20) {
      00068D 05 39            [12] 1761 	inc	_update_sweep_walkCount_65536_35
      00068F E4               [12] 1762 	clr	a
      000690 B5 39 02         [24] 1763 	cjne	a,_update_sweep_walkCount_65536_35,00288$
      000693 05 3A            [12] 1764 	inc	(_update_sweep_walkCount_65536_35 + 1)
      000695                       1765 00288$:
      000695 AE 39            [24] 1766 	mov	r6,_update_sweep_walkCount_65536_35
      000697 AF 3A            [24] 1767 	mov	r7,(_update_sweep_walkCount_65536_35 + 1)
      000699 C3               [12] 1768 	clr	c
      00069A EE               [12] 1769 	mov	a,r6
      00069B 94 14            [12] 1770 	subb	a,#0x14
      00069D EF               [12] 1771 	mov	a,r7
      00069E 94 00            [12] 1772 	subb	a,#0x00
      0006A0 40 62            [24] 1773 	jc	00164$
                                   1774 ;	AT89S52-Buzzer.c:289: walkCount = 0;
      0006A2 E4               [12] 1775 	clr	a
      0006A3 F5 39            [12] 1776 	mov	_update_sweep_walkCount_65536_35,a
      0006A5 F5 3A            [12] 1777 	mov	(_update_sweep_walkCount_65536_35 + 1),a
                                   1778 ;	AT89S52-Buzzer.c:290: currentFreqDelay += (simple_rand() % 5) - 2;
      0006A7 C0 05            [24] 1779 	push	ar5
      0006A9 C0 04            [24] 1780 	push	ar4
      0006AB 12 01 DA         [24] 1781 	lcall	_simple_rand
      0006AE AF 82            [24] 1782 	mov	r7,dpl
      0006B0 7E 00            [12] 1783 	mov	r6,#0x00
      0006B2 74 05            [12] 1784 	mov	a,#0x05
      0006B4 C0 E0            [24] 1785 	push	acc
      0006B6 E4               [12] 1786 	clr	a
      0006B7 C0 E0            [24] 1787 	push	acc
      0006B9 8F 82            [24] 1788 	mov	dpl,r7
      0006BB 8E 83            [24] 1789 	mov	dph,r6
      0006BD 12 09 0E         [24] 1790 	lcall	__modsint
      0006C0 AE 82            [24] 1791 	mov	r6,dpl
      0006C2 AF 83            [24] 1792 	mov	r7,dph
      0006C4 15 81            [12] 1793 	dec	sp
      0006C6 15 81            [12] 1794 	dec	sp
      0006C8 D0 04            [24] 1795 	pop	ar4
      0006CA D0 05            [24] 1796 	pop	ar5
      0006CC EE               [12] 1797 	mov	a,r6
      0006CD 24 FE            [12] 1798 	add	a,#0xfe
      0006CF FE               [12] 1799 	mov	r6,a
      0006D0 EF               [12] 1800 	mov	a,r7
      0006D1 34 FF            [12] 1801 	addc	a,#0xff
      0006D3 FF               [12] 1802 	mov	r7,a
      0006D4 AA 24            [24] 1803 	mov	r2,_currentFreqDelay
      0006D6 AB 25            [24] 1804 	mov	r3,(_currentFreqDelay + 1)
      0006D8 EE               [12] 1805 	mov	a,r6
      0006D9 2A               [12] 1806 	add	a,r2
      0006DA FA               [12] 1807 	mov	r2,a
      0006DB EF               [12] 1808 	mov	a,r7
      0006DC 3B               [12] 1809 	addc	a,r3
      0006DD FB               [12] 1810 	mov	r3,a
      0006DE 8A 24            [24] 1811 	mov	_currentFreqDelay,r2
      0006E0 8B 25            [24] 1812 	mov	(_currentFreqDelay + 1),r3
                                   1813 ;	AT89S52-Buzzer.c:291: if(currentFreqDelay < minDelay) currentFreqDelay = minDelay;
      0006E2 C3               [12] 1814 	clr	c
      0006E3 E5 24            [12] 1815 	mov	a,_currentFreqDelay
      0006E5 9C               [12] 1816 	subb	a,r4
      0006E6 E5 25            [12] 1817 	mov	a,(_currentFreqDelay + 1)
      0006E8 9D               [12] 1818 	subb	a,r5
      0006E9 50 04            [24] 1819 	jnc	00158$
      0006EB 8C 24            [24] 1820 	mov	_currentFreqDelay,r4
      0006ED 8D 25            [24] 1821 	mov	(_currentFreqDelay + 1),r5
      0006EF                       1822 00158$:
                                   1823 ;	AT89S52-Buzzer.c:292: if(currentFreqDelay > maxDelay) currentFreqDelay = maxDelay;
      0006EF A8 08            [24] 1824 	mov	r0,_bp
      0006F1 08               [12] 1825 	inc	r0
      0006F2 C3               [12] 1826 	clr	c
      0006F3 E6               [12] 1827 	mov	a,@r0
      0006F4 95 24            [12] 1828 	subb	a,_currentFreqDelay
      0006F6 08               [12] 1829 	inc	r0
      0006F7 E6               [12] 1830 	mov	a,@r0
      0006F8 95 25            [12] 1831 	subb	a,(_currentFreqDelay + 1)
      0006FA 50 08            [24] 1832 	jnc	00164$
      0006FC A8 08            [24] 1833 	mov	r0,_bp
      0006FE 08               [12] 1834 	inc	r0
      0006FF 86 24            [24] 1835 	mov	_currentFreqDelay,@r0
      000701 08               [12] 1836 	inc	r0
      000702 86 25            [24] 1837 	mov	(_currentFreqDelay + 1),@r0
                                   1838 ;	AT89S52-Buzzer.c:295: }
      000704                       1839 00164$:
                                   1840 ;	AT89S52-Buzzer.c:296: }
      000704 85 08 81         [24] 1841 	mov	sp,_bp
      000707 D0 08            [24] 1842 	pop	_bp
      000709 22               [24] 1843 	ret
                                   1844 ;------------------------------------------------------------
                                   1845 ;Allocation info for local variables in function 'main'
                                   1846 ;------------------------------------------------------------
                                   1847 ;	AT89S52-Buzzer.c:299: void main() {
                                   1848 ;	-----------------------------------------
                                   1849 ;	 function main
                                   1850 ;	-----------------------------------------
      00070A                       1851 _main:
                                   1852 ;	AT89S52-Buzzer.c:301: P0 = P1 = P2 = P3 = 0xFF; // All LEDs off (active low)
      00070A 75 B0 FF         [24] 1853 	mov	_P3,#0xff
      00070D 75 A0 FF         [24] 1854 	mov	_P2,#0xff
      000710 75 90 FF         [24] 1855 	mov	_P1,#0xff
      000713 75 80 FF         [24] 1856 	mov	_P0,#0xff
                                   1857 ;	AT89S52-Buzzer.c:302: TMOD = 0x01;               // Timer 0 mode 1
      000716 75 89 01         [24] 1858 	mov	_TMOD,#0x01
                                   1859 ;	AT89S52-Buzzer.c:303: TH0 = 0xFC; TL0 = 0x66;    // 1ms timer @12MHz
      000719 75 8C FC         [24] 1860 	mov	_TH0,#0xfc
      00071C 75 8A 66         [24] 1861 	mov	_TL0,#0x66
                                   1862 ;	AT89S52-Buzzer.c:304: ET0 = 1;                   // Enable Timer 0 interrupt
                                   1863 ;	assignBit
      00071F D2 A9            [12] 1864 	setb	_ET0
                                   1865 ;	AT89S52-Buzzer.c:305: TR0 = 1;                   // Start Timer 0
                                   1866 ;	assignBit
      000721 D2 8C            [12] 1867 	setb	_TR0
                                   1868 ;	AT89S52-Buzzer.c:306: EA = 1;                    // Enable global interrupts
                                   1869 ;	assignBit
      000723 D2 AF            [12] 1870 	setb	_EA
                                   1871 ;	AT89S52-Buzzer.c:309: currentRange = 0;
                                   1872 ;	assignBit
      000725 C2 01            [12] 1873 	clr	_currentRange
                                   1874 ;	AT89S52-Buzzer.c:310: currentFreqDelay = rangeParams[currentRange][2];
      000727 90 09 98         [24] 1875 	mov	dptr,#(_rangeParams + 0x0004)
      00072A E4               [12] 1876 	clr	a
      00072B 93               [24] 1877 	movc	a,@a+dptr
      00072C F5 24            [12] 1878 	mov	_currentFreqDelay,a
      00072E A3               [24] 1879 	inc	dptr
      00072F E4               [12] 1880 	clr	a
      000730 93               [24] 1881 	movc	a,@a+dptr
      000731 F5 25            [12] 1882 	mov	(_currentFreqDelay + 1),a
                                   1883 ;	AT89S52-Buzzer.c:311: updateStatusLEDs();
      000733 12 01 12         [24] 1884 	lcall	_updateStatusLEDs
                                   1885 ;	AT89S52-Buzzer.c:314: while(1) {
      000736                       1886 00118$:
                                   1887 ;	AT89S52-Buzzer.c:316: if(checkButton_PWR()) {
      000736 12 02 38         [24] 1888 	lcall	_checkButton_PWR
      000739 50 0A            [24] 1889 	jnc	00104$
                                   1890 ;	AT89S52-Buzzer.c:317: isActive = !isActive;
      00073B B2 00            [12] 1891 	cpl	_isActive
                                   1892 ;	AT89S52-Buzzer.c:318: if(!isActive) BUZZER = 0;
      00073D 20 00 02         [24] 1893 	jb	_isActive,00102$
                                   1894 ;	assignBit
      000740 C2 B0            [12] 1895 	clr	_BUZZER
      000742                       1896 00102$:
                                   1897 ;	AT89S52-Buzzer.c:319: updateStatusLEDs();
      000742 12 01 12         [24] 1898 	lcall	_updateStatusLEDs
      000745                       1899 00104$:
                                   1900 ;	AT89S52-Buzzer.c:322: if(checkButton_PAT()) {
      000745 12 02 5E         [24] 1901 	lcall	_checkButton_PAT
      000748 50 0E            [24] 1902 	jnc	00108$
                                   1903 ;	AT89S52-Buzzer.c:323: if(++currentPattern >= 11) currentPattern = 0;
      00074A 05 22            [12] 1904 	inc	_currentPattern
      00074C 74 F5            [12] 1905 	mov	a,#0x100 - 0x0b
      00074E 25 22            [12] 1906 	add	a,_currentPattern
      000750 50 03            [24] 1907 	jnc	00106$
      000752 75 22 00         [24] 1908 	mov	_currentPattern,#0x00
      000755                       1909 00106$:
                                   1910 ;	AT89S52-Buzzer.c:324: updateStatusLEDs();
      000755 12 01 12         [24] 1911 	lcall	_updateStatusLEDs
      000758                       1912 00108$:
                                   1913 ;	AT89S52-Buzzer.c:327: if(checkButton_SPD()) {
      000758 12 02 84         [24] 1914 	lcall	_checkButton_SPD
      00075B 50 0E            [24] 1915 	jnc	00112$
                                   1916 ;	AT89S52-Buzzer.c:328: if(++currentSpeed >= 5) currentSpeed = 0;
      00075D 05 23            [12] 1917 	inc	_currentSpeed
      00075F 74 FB            [12] 1918 	mov	a,#0x100 - 0x05
      000761 25 23            [12] 1919 	add	a,_currentSpeed
      000763 50 03            [24] 1920 	jnc	00110$
      000765 75 23 00         [24] 1921 	mov	_currentSpeed,#0x00
      000768                       1922 00110$:
                                   1923 ;	AT89S52-Buzzer.c:329: updateStatusLEDs();
      000768 12 01 12         [24] 1924 	lcall	_updateStatusLEDs
      00076B                       1925 00112$:
                                   1926 ;	AT89S52-Buzzer.c:332: if(checkButton_RNG()) {
      00076B 12 02 AA         [24] 1927 	lcall	_checkButton_RNG
      00076E 50 37            [24] 1928 	jnc	00114$
                                   1929 ;	AT89S52-Buzzer.c:333: currentRange = !currentRange;
      000770 B2 01            [12] 1930 	cpl	_currentRange
                                   1931 ;	AT89S52-Buzzer.c:334: currentFreqDelay = rangeParams[currentRange][2];
      000772 A2 01            [12] 1932 	mov	c,_currentRange
      000774 E4               [12] 1933 	clr	a
      000775 33               [12] 1934 	rlc	a
      000776 FE               [12] 1935 	mov	r6,a
      000777 7F 00            [12] 1936 	mov	r7,#0x00
      000779 C0 06            [24] 1937 	push	ar6
      00077B C0 07            [24] 1938 	push	ar7
      00077D 90 00 06         [24] 1939 	mov	dptr,#0x0006
      000780 12 07 B6         [24] 1940 	lcall	__mulint
      000783 AE 82            [24] 1941 	mov	r6,dpl
      000785 AF 83            [24] 1942 	mov	r7,dph
      000787 15 81            [12] 1943 	dec	sp
      000789 15 81            [12] 1944 	dec	sp
      00078B EE               [12] 1945 	mov	a,r6
      00078C 24 94            [12] 1946 	add	a,#_rangeParams
      00078E FE               [12] 1947 	mov	r6,a
      00078F EF               [12] 1948 	mov	a,r7
      000790 34 09            [12] 1949 	addc	a,#(_rangeParams >> 8)
      000792 FF               [12] 1950 	mov	r7,a
      000793 8E 82            [24] 1951 	mov	dpl,r6
      000795 8F 83            [24] 1952 	mov	dph,r7
      000797 A3               [24] 1953 	inc	dptr
      000798 A3               [24] 1954 	inc	dptr
      000799 A3               [24] 1955 	inc	dptr
      00079A A3               [24] 1956 	inc	dptr
      00079B E4               [12] 1957 	clr	a
      00079C 93               [24] 1958 	movc	a,@a+dptr
      00079D F5 24            [12] 1959 	mov	_currentFreqDelay,a
      00079F A3               [24] 1960 	inc	dptr
      0007A0 E4               [12] 1961 	clr	a
      0007A1 93               [24] 1962 	movc	a,@a+dptr
      0007A2 F5 25            [12] 1963 	mov	(_currentFreqDelay + 1),a
                                   1964 ;	AT89S52-Buzzer.c:335: updateStatusLEDs();
      0007A4 12 01 12         [24] 1965 	lcall	_updateStatusLEDs
      0007A7                       1966 00114$:
                                   1967 ;	AT89S52-Buzzer.c:339: if(isActive) {
      0007A7 20 00 03         [24] 1968 	jb	_isActive,00165$
      0007AA 02 07 36         [24] 1969 	ljmp	00118$
      0007AD                       1970 00165$:
                                   1971 ;	AT89S52-Buzzer.c:340: generate_tone();
      0007AD 12 02 D0         [24] 1972 	lcall	_generate_tone
                                   1973 ;	AT89S52-Buzzer.c:341: update_sweep();
      0007B0 12 02 ED         [24] 1974 	lcall	_update_sweep
                                   1975 ;	AT89S52-Buzzer.c:344: }
      0007B3 02 07 36         [24] 1976 	ljmp	00118$
                                   1977 	.area CSEG    (CODE)
                                   1978 	.area CONST   (CODE)
      000994                       1979 _rangeParams:
      000994 19 00                 1980 	.byte #0x19, #0x00	; 25
      000996 32 00                 1981 	.byte #0x32, #0x00	; 50
      000998 25 00                 1982 	.byte #0x25, #0x00	; 37
      00099A 09 00                 1983 	.byte #0x09, #0x00	; 9
      00099C 12 00                 1984 	.byte #0x12, #0x00	; 18
      00099E 0D 00                 1985 	.byte #0x0d, #0x00	; 13
      0009A0                       1986 _speedSteps:
      0009A0 01                    1987 	.db #0x01	; 1
      0009A1 02                    1988 	.db #0x02	; 2
      0009A2 03                    1989 	.db #0x03	; 3
      0009A3 05                    1990 	.db #0x05	; 5
      0009A4 08                    1991 	.db #0x08	; 8
                                   1992 	.area XINIT   (CODE)
                                   1993 	.area CABS    (ABS,CODE)
