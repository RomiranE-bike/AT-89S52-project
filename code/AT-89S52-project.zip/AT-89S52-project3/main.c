/**
 * AT89S52 Buzzer Controller with Sweep Patterns
 * Keil-compatible version with proper variable declarations
 */

#include <reg52.h>
#include <intrins.h>

/*----- Hardware Connections -----*/
sbit LED = P2^0;
sbit BUZZER = P2^1;
sbit BTN_POWER = P3^2;
sbit BTN_PATTERN = P3^3;
sbit BTN_SPEED = P3^4;

/*----- System State -----*/
bit isActive = 0;
bit lastState_PWR = 1;
bit lastState_PAT = 1;
bit lastState_SPD = 1;

/*----- Sound Parameters -----*/
unsigned int currentFreqDelay = 250;
unsigned char currentPattern = 0;
unsigned char currentSpeed = 2;
bit sweepDirection = 0;

/*----- Timer 0 ISR -----*/
void Timer0_ISR() interrupt 1 {
    static unsigned int msCount = 0;
    TH0 = 0xFC; TL0 = 0x66;
    
    if(isActive && ++msCount >= 50) {
        LED = !LED;
        msCount = 0;
    }
}

/*----- Button Check Functions -----*/
bit checkButton_PWR() {
    bit current = BTN_POWER;
    unsigned char i; // Declare at start
    
    if(current != lastState_PWR) {
        for(i=0; i<20; i++) _nop_();
        if(BTN_POWER == current) {
            lastState_PWR = current;
            return !current;
        }
    }
    return 0;
}

bit checkButton_PAT() {
    bit current = BTN_PATTERN;
    unsigned char i; // Declare at start
    
    if(current != lastState_PAT) {
        for(i=0; i<20; i++) _nop_();
        if(BTN_PATTERN == current) {
            lastState_PAT = current;
            return !current;
        }
    }
    return 0;
}

bit checkButton_SPD() {
    bit current = BTN_SPEED;
    unsigned char i; // Declare at start
    
    if(current != lastState_SPD) {
        for(i=0; i<20; i++) _nop_();
        if(BTN_SPEED == current) {
            lastState_SPD = current;
            return !current;
        }
    }
    return 0;
}

/*----- Button Handlers -----*/
void handleButtons() {
    /* Power Button */
    if(checkButton_PWR()) {
        isActive = !isActive;
        if(!isActive) { LED = 0; BUZZER = 0; }
    }
    
    /* Pattern Button */
    if(checkButton_PAT()) {
        unsigned char i, j; // Declare at start
        
        currentPattern = (currentPattern + 1) % 4;
        LED = 0;
        for(i=0; i<=currentPattern; i++) {
            LED = 1;
            for(j=0; j<100; j++) _nop_();
            LED = 0;
            for(j=0; j<100; j++) _nop_();
        }
    }
    
    /* Speed Button */
    if(checkButton_SPD()) {
        unsigned char i, j; // Declare at start
        
        currentSpeed = (currentSpeed + 1) % 5;
        LED = 0;
        for(i=0; i<=currentSpeed; i++) {
            LED = 1;
            for(j=0; j<50; j++) _nop_();
            LED = 0;
            for(j=0; j<50; j++) _nop_();
        }
    }
}

/*----- Tone Generation -----*/
void generate_tone() {
    unsigned int i; // Declare at start
    
    BUZZER = !BUZZER;
    for(i=0; i<currentFreqDelay; i++) _nop_();
}

/*----- Sweep Patterns -----*/
void update_sweep() {
    static unsigned char speedSteps[5] = {1, 2, 3, 5, 8};
    
    switch(currentPattern) {
        case 0: /* Up Sweep */
            if(currentFreqDelay > 166) currentFreqDelay -= speedSteps[currentSpeed];
            else currentFreqDelay = 500;
            break;
            
        case 1: /* Down Sweep */
            if(currentFreqDelay < 500) currentFreqDelay += speedSteps[currentSpeed];
            else currentFreqDelay = 166;
            break;
            
        case 2: /* Zig-Zag */
            if(sweepDirection) {
                if(currentFreqDelay < 500) currentFreqDelay += speedSteps[currentSpeed];
                else sweepDirection = 0;
            } else {
                if(currentFreqDelay > 166) currentFreqDelay -= speedSteps[currentSpeed];
                else sweepDirection = 1;
            }
            break;
            
        case 3: /* Random */
            currentFreqDelay = 166 + (currentFreqDelay % 334);
            break;
    }
}

void main() {
    /* Initialize */
    LED = BUZZER = 0;
    TMOD = 0x01;
    TH0 = 0xFC; TL0 = 0x66;
    ET0 = TR0 = EA = 1;
    
    /* Main Loop */
    while(1) {
        handleButtons();
        if(isActive) {
            generate_tone();
            update_sweep();
        }
    }
}