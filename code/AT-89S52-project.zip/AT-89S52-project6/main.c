/**
 * AT89S52 Buzzer Controller - 1kHz to 10kHz Frequency Range
 * - Updated delay values for wider frequency range
 * - Maintained all pattern and speed functionality
 */

#include <reg52.h>
#include <intrins.h>
//-------------------------------------------------------------------------------------------------
/*----- Hardware Connections -----*/
// Status LEDs
sbit POWER_LED = P2^0;    // Red
sbit SPEED_LED = P2^1;    // Blue

// Pattern LEDs
sbit UP_LED    = P2^2;    // Green 
sbit DOWN_LED  = P2^3;    // Yellow
sbit ZIGZAG_LED= P2^4;    // Cyan
sbit RAND_LED  = P2^5;    // Purple

sbit BUZZER = P2^6;       // Buzzer

sbit BTN_POWER = P3^2;    // Power
sbit BTN_PATTERN = P3^3;  // Pattern
sbit BTN_SPEED = P3^4;    // Speed

/*----- System State -----*/
bit isActive = 0;
bit lastState_PWR = 1;
bit lastState_PAT = 1;
bit lastState_SPD = 1;
//-------------------------------------------------------------------------------------------------
/*----- Sound Parameters -----*/
unsigned int currentFreqDelay = 100;  // Initial midpoint value (~3kHz)
unsigned char currentPattern = 0;
unsigned char currentSpeed = 0;
bit sweepDirection = 0;

/*----- Frequency Control -----*/
#define MIN_DELAY 25   // ~10kHz (1/(2*25*2�s)) = 10,000Hz
#define MAX_DELAY 250  // ~1kHz (1/(2*250*2�s)) = 1,000Hz
//-------------------------------------------------------------------------------------------------
/*----- Custom Delay Function -----*/
void delay_ms(unsigned int ms) {
    unsigned int i, j;
    for(i=0; i<ms; i++)
        for(j=0; j<120; j++);  // ~1ms at 12MHz
}
//-------------------------------------------------------------------------------------------------
/*----- Timer 0 ISR -----*/
void Timer0_ISR() interrupt 1 {
    static unsigned int msCount = 0;
    TH0 = 0xFC; TL0 = 0x66;
    
    if(isActive) {
        if(++msCount >= 100) {  // 5Hz blink @12MHz
            SPEED_LED = !SPEED_LED;
            msCount = 0;
        }
    } else {
        SPEED_LED = 0;
    }
}
//-------------------------------------------------------------------------------------------------
/*----- Update Status LEDs -----*/
void updateStatusLEDs() {
    POWER_LED = isActive;
    UP_LED    = (currentPattern == 0);
    DOWN_LED  = (currentPattern == 1);
    ZIGZAG_LED= (currentPattern == 2);
    RAND_LED  = (currentPattern == 3);
}
//-------------------------------------------------------------------------------------------------
/*----- Button Check Functions -----*/
// (Unchanged button check functions remain the same)
bit checkButton_PWR() {
    bit current = BTN_POWER;
    unsigned char i;
    
    if(current != lastState_PWR) {
        for(i=0; i<20; i++) _nop_();
        if(BTN_POWER == current) {
            lastState_PWR = current;
            return !current;
        }
    }
    return 0;
}
//-------------------------------------------------------------------------------------------------
bit checkButton_PAT() {
    bit current = BTN_PATTERN;
    unsigned char i;
    
    if(current != lastState_PAT) {
        for(i=0; i<20; i++) _nop_();
        if(BTN_PATTERN == current) {
            lastState_PAT = current;
            return !current;
        }
    }
    return 0;
}
//-------------------------------------------------------------------------------------------------
bit checkButton_SPD() {
    bit current = BTN_SPEED;
    unsigned char i;
    
    if(current != lastState_SPD) {
        for(i=0; i<20; i++) _nop_();
        if(BTN_SPEED == current) {
            lastState_SPD = current;
            return !current;
        }
    }
    return 0;
}
//-------------------------------------------------------------------------------------------------
/*----- Button Handlers -----*/
void handleButtons() {
    /* Power Button */
    if(checkButton_PWR()) {
        isActive = !isActive;
        if(!isActive) BUZZER = 0;
        updateStatusLEDs();
    }
    
    /* Pattern Button */
    if(checkButton_PAT()) {
        currentPattern = (currentPattern + 1) % 4;
        updateStatusLEDs();
        SPEED_LED = 1; delay_ms(50); SPEED_LED = 0;
    }
    
    /* Speed Button */
    if(checkButton_SPD()) {
        currentSpeed = (currentSpeed + 1) % 5;
        updateStatusLEDs();
    }
}
//-------------------------------------------------------------------------------------------------
/*----- Tone Generation -----*/
void generate_tone() {
    unsigned int i;
    BUZZER = !BUZZER;
    for(i=0; i<currentFreqDelay; i++) _nop_();  // Each loop ~2�s at 12MHz
}
//-------------------------------------------------------------------------------------------------
/*----- Sweep Patterns -----*/
void update_sweep() {
    static unsigned char speedSteps[5] = {1, 2, 3, 5, 8};
    
    switch(currentPattern) {
        case 0: // Up Sweep (1kHz?10kHz)
            if(currentFreqDelay > MIN_DELAY)
                currentFreqDelay -= speedSteps[currentSpeed];
            else
                currentFreqDelay = MAX_DELAY;
            break;
            
        case 1: // Down Sweep (10kHz?1kHz)
            if(currentFreqDelay < MAX_DELAY)
                currentFreqDelay += speedSteps[currentSpeed];
            else
                currentFreqDelay = MIN_DELAY;
            break;
            
        case 2: // Zig-Zag
            if(sweepDirection) {
                if(currentFreqDelay < MAX_DELAY)
                    currentFreqDelay += speedSteps[currentSpeed];
                else
                    sweepDirection = 0;
            } else {
                if(currentFreqDelay > MIN_DELAY)
                    currentFreqDelay -= speedSteps[currentSpeed];
                else
                    sweepDirection = 1;
            }
            break;
            
        case 3: // Random
            currentFreqDelay = MIN_DELAY + (currentFreqDelay % (MAX_DELAY-MIN_DELAY+1));
            break;
    }
}
//-------------------------------------------------------------------------------------------------
void main() {
    /* Initialize */
    POWER_LED = SPEED_LED = UP_LED = DOWN_LED = ZIGZAG_LED = RAND_LED = 0;
    TMOD = 0x01;
    TH0 = 0xFC; TL0 = 0x66;
    ET0 = TR0 = EA = 1;
    
    /* Main Loop */
    while(1) {
        handleButtons();
        if(isActive) {
            generate_tone();
            update_sweep();
        }
    }
}
//-------------------------------------------------------------------------------------------------