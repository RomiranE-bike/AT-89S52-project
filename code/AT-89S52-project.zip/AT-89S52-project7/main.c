/**
 * AT89S52 Dog Repeller - Final Working Version
 * Fixed all compiler errors and warnings
 * Two modes: Sweep/Random (18-25kHz) or Constant (22kHz)
 */

#include <reg52.h>
#include <intrins.h>
#include <stdlib.h>

/*----- Hardware Connections -----*/
sbit BUZZER = P1^0;      // PWM output
sbit LED = P2^0;         // Status LED
sbit BTN_POWER = P3^2;   // Power button
sbit BTN_MODE = P3^3;    // Pattern mode button

/*----- Dog Frequency Settings -----*/
#define MIN_FREQ 18000   // 18kHz
#define MAX_FREQ 25000   // 25kHz
#define CONST_FREQ 22000 // 22kHz constant
#define SWEEP_SPEED 300  // Hz/step

/*----- Function Prototypes -----*/
void init_pwm(void);
void set_freq(unsigned int freq);
bit button_pressed(bit pin_state);
void update_sweep(void);
void delay(unsigned int cycles);

/*----- System Variables -----*/
bit is_active = 0;
bit use_pattern = 1;     // Default to sweep+random mode
unsigned int current_freq = 22000;

/*----- Timer Initialization -----*/
void init_pwm() {
    TMOD |= 0x10;       // Timer1 mode 16-bit
    ET1 = 0;            // No interrupt
    TR1 = 1;            // Run timer
}

void set_freq(unsigned int freq) {
    unsigned long reload = 65536 - (12000000UL/(12L*freq));
    TH1 = reload >> 8;
    TL1 = reload & 0xFF;
}

/*----- Button Debouncing -----*/
bit button_pressed(bit pin_state) {
    static bit last_state = 1;
    if(pin_state != last_state) {
        _nop_(); _nop_(); _nop_(); // Short delay
        if(pin_state != last_state) {
            last_state = pin_state;
            return !pin_state; // Active-low button
        }
    }
    return 0;
}

/*----- Pattern Updates -----*/
void update_sweep() {
    static bit sweep_dir = 0;
    static unsigned char pattern_counter = 0;
    
    if(++pattern_counter > 100) { // Every ~5s
        pattern_counter = 0;
        current_freq = MIN_FREQ + (rand()%(MAX_FREQ-MIN_FREQ));
    } else {
        // Linear sweep
        if(sweep_dir) {
            current_freq += SWEEP_SPEED;
            if(current_freq >= MAX_FREQ) sweep_dir = 0;
        } else {
            current_freq -= SWEEP_SPEED;
            if(current_freq <= MIN_FREQ) sweep_dir = 1;
        }
    }
}

/*----- Delay Function -----*/
void delay(unsigned int cycles) {
    while(cycles--) {
        _nop_();
    }
}

/*----- Main Control Loop -----*/
void main() {
    // Initialize
    init_pwm();
    LED = 0;
    srand(0x1234); // Seed RNG
    
    while(1) {
        // Power Toggle
        if(button_pressed(BTN_POWER)) {
            is_active = !is_active;
            LED = is_active;
            if(!is_active) BUZZER = 0;
        }
        
        // Pattern Mode Toggle
        if(button_pressed(BTN_MODE)) {
            use_pattern = !use_pattern;
            LED = 0; // Blink feedback
            delay(10000); // ~30ms
            LED = is_active;
        }
        
        // Active Operation
        if(is_active) {
            if(use_pattern) {
                update_sweep();
            } else {
                current_freq = CONST_FREQ; // Constant frequency
            }
            set_freq(current_freq);
            BUZZER = !BUZZER; // Visible in simulation
            delay(200); // ~600�s delay
        }
    }
}