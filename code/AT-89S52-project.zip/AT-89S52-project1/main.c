/**
 * AT89S52 LED & Buzzer Controller
 * Hardware:
 * - 12MHz crystal
 * - LED on P2.0
 * - Passive buzzer on P2.1
 * - Button on P3.2 (INT0)
 * Features:
 * - Toggles LED every 500ms when active
 * - Generates 2kHz beep while active
 * - Button controls on/off state
 */

#include <reg52.h>    // Standard 8051 registers
#include <intrins.h>  // Required for _nop_()

/* Hardware Connections */
sbit LED = P2^0;     // LED connected to P2.0
sbit BUZZER = P2^1;  // Passive buzzer on P2.1
sbit BUTTON = P3^2;  // Pushbutton on P3.2 (INT0)

/* Global Variables */
bit isActive = 0;    // System state flag

/**
 * Timer 0 Interrupt Service Routine
 * - Called every 1ms (with 12MHz crystal)
 * - Manages LED timing
 */
void Timer0_ISR(void) interrupt 1
{
    static unsigned int msCount = 0;
    
    TH0 = 0xFC;  // Reload for 1ms @ 12MHz
    TL0 = 0x66;
    
    if(isActive) {
        if(++msCount >= 50) {  // 50ms period
            LED = !LED;         // Toggle LED
            msCount = 0;
        }
    }
}

/**
 * External Interrupt 0 Service Routine
 * - Triggered by button press
 * - Toggles system state
 */
void INT0_ISR(void) interrupt 0
{
    isActive = !isActive;  // Toggle state
    
    // Turn off outputs when deactivated
    if(!isActive) {
        LED = 0;
        BUZZER = 0;
    }
    
    // Simple debounce delay
    _nop_(); _nop_(); _nop_(); _nop_(); _nop_();
    _nop_(); _nop_(); _nop_(); _nop_(); _nop_();
    while(!BUTTON);  // Wait for button release
}

/**
 * Generate 2kHz tone on buzzer
 * @param duration_ms - how long to beep (in ms)
 */
void beep_2kHz(unsigned int duration_ms,unsigned int fd_ms)
{
    unsigned int i;
	  unsigned int d;
    for(i = 0; i < duration_ms; i++) {
        BUZZER = !BUZZER;  // Toggle buzzer pin
        for(d = 0; d < fd_ms; d++){_nop_();}//  delay (for  square wave)                
    }
    BUZZER = 0;  // Ensure buzzer is off
}

/**
 * Main Program
 */
void main(void)
{
    /* Initialize Hardware */
    LED = 0;      // Start with LED off
    BUZZER = 0;   // Start with buzzer off
    BUTTON = 1;   // Enable pull-up
    
    /* Timer 0 Setup (1ms interrupts) */
    TMOD = 0x01;  // Timer 0, Mode 1 (16-bit)
    TH0 = 0xFC;   // Initial values for 1ms
    TL0 = 0x66;   // @12MHz
    ET0 = 1;      // Enable Timer 0 interrupt
    TR0 = 1;      // Start Timer 0
    
    /* Interrupt Configuration */
    IT0 = 1;      // INT0 edge-triggered
    EX0 = 1;      // Enable INT0 interrupt
    EA = 1;       // Global interrupt enable
    
    /* Main Super Loop */
    while(1) {
        if(isActive) {
            beep_2kHz(500,20);  
        }
    }
}